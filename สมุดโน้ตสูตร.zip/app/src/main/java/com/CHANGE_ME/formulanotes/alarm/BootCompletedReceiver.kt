package com.CHANGE_ME.formulanotes.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.CHANGE_ME.formulanotes.data.local.AppDatabase
import com.CHANGE_ME.formulanotes.data.local.UserPreferencesRepository
import com.CHANGE_ME.formulanotes.widget.ExamCountdownWidgetUpdater
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootCompletedReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return

        val pendingResult = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val prefs = UserPreferencesRepository(appContext).preferencesFlow.first()
                val db = AppDatabase.getInstance(appContext)
                val exams = db.noteDao().getAllExamsSnapshot()
                ExamNotificationScheduler.rescheduleAll(
                    context = appContext,
                    exams = exams,
                    enabled = prefs.examNotificationsEnabled
                )
                ExamCountdownWidgetUpdater.updateAll(appContext)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
