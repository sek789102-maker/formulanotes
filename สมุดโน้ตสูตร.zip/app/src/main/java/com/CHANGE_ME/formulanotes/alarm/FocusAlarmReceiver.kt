package com.CHANGE_ME.formulanotes.alarm

import android.Manifest
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.CHANGE_ME.formulanotes.MainActivity
import com.CHANGE_ME.formulanotes.R
import com.CHANGE_ME.formulanotes.data.local.AppDatabase
import com.CHANGE_ME.formulanotes.data.local.UserPreferencesRepository
import com.CHANGE_ME.formulanotes.data.model.FocusPreset
import com.CHANGE_ME.formulanotes.data.model.StudySessionEntity
import com.CHANGE_ME.formulanotes.data.model.SubjectCategory
import com.CHANGE_ME.formulanotes.data.model.resolveDisplayName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class FocusAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent == null) return
        val endAtMillis = intent.getLongExtra(FocusAlarmScheduler.EXTRA_END_AT_MILLIS, 0L)
        val preset = FocusPreset.fromName(intent.getStringExtra(FocusAlarmScheduler.EXTRA_PRESET_NAME))
        val subjectId = intent.getStringExtra(FocusAlarmScheduler.EXTRA_SUBJECT_ID) ?: SubjectCategory.MATH.name

        val pendingResult = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val prefsRepo = UserPreferencesRepository(appContext)
                val claimed = if (endAtMillis > 0L) {
                    prefsRepo.consumeFocusTimerCompletion(endAtMillis)
                } else {
                    true
                }

                if (claimed) {
                    val db = AppDatabase.getInstance(appContext)
                    val subjectEntity = db.noteDao().getSubjectById(subjectId)
                    if (preset.isStudy) {
                        db.noteDao().insertStudySession(
                            StudySessionEntity(
                                subject = subjectId,
                                durationMinutes = preset.minutes
                            )
                        )
                    }
                    val subjectLabel = subjectEntity.resolveDisplayName(appContext)
                    postCompletionNotification(appContext, preset, subjectLabel)
                    triggerCompletionVibration(appContext)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun postCompletionNotification(
        context: Context,
        preset: FocusPreset,
        subjectLabel: String
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        FocusAlarmScheduler.createNotificationChannel(context)

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            1001,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val presetLabel = context.getString(preset.labelRes)
        val title = if (preset.isStudy) {
            context.getString(R.string.notification_focus_done_title, presetLabel)
        } else {
            context.getString(R.string.notification_break_done_title)
        }
        val body = if (preset.isStudy) {
            context.getString(R.string.notification_focus_done_body, subjectLabel)
        } else {
            context.getString(R.string.notification_break_done_body)
        }

        val notification = NotificationCompat.Builder(context, FocusAlarmScheduler.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_monochrome)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(contentPendingIntent)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIFICATION_ID, notification)
    }

    @Suppress("DEPRECATION")
    private fun triggerCompletionVibration(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                manager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(500L, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(500L, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    vibrator?.vibrate(500L)
                }
            }
        } catch (_: Exception) {
        }
    }

    companion object {
        private const val NOTIFICATION_ID = 4202
    }
}
