package com.CHANGE_ME.formulanotes.alarm

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.CHANGE_ME.formulanotes.R
import com.CHANGE_ME.formulanotes.data.model.FocusPreset

object FocusAlarmScheduler {

    const val CHANNEL_ID = "focus_timer_channel"
    const val EXTRA_END_AT_MILLIS = "extra_end_at_millis"
    const val EXTRA_PRESET_NAME = "extra_preset_name"
    const val EXTRA_SUBJECT_ID = "extra_subject_id"
    private const val REQUEST_CODE = 4201

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                ?: return
            val existing = manager.getNotificationChannel(CHANNEL_ID)
            if (existing != null) return

            val channel = NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.notification_channel_focus_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = context.getString(R.string.notification_channel_focus_desc)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 350, 150, 350)
            }
            manager.createNotificationChannel(channel)
        }
    }

    fun schedule(
        context: Context,
        endAtMillis: Long,
        preset: FocusPreset,
        subjectId: String
    ) {
        createNotificationChannel(context)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val pendingIntent = buildPendingIntent(context, endAtMillis, preset, subjectId)

        try {
            val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                alarmManager.canScheduleExactAlarms()
            } else {
                true
            }
            if (canExact) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    endAtMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    endAtMillis,
                    pendingIntent
                )
            }
        } catch (_: SecurityException) {
            alarmManager.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                endAtMillis,
                pendingIntent
            )
        }
    }

    fun cancel(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, FocusAlarmReceiver::class.java)
        val existing = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (existing != null) {
            alarmManager.cancel(existing)
            existing.cancel()
        }
    }

    private fun buildPendingIntent(
        context: Context,
        endAtMillis: Long,
        preset: FocusPreset,
        subjectId: String
    ): PendingIntent {
        val intent = Intent(context, FocusAlarmReceiver::class.java).apply {
            putExtra(EXTRA_END_AT_MILLIS, endAtMillis)
            putExtra(EXTRA_PRESET_NAME, preset.name)
            putExtra(EXTRA_SUBJECT_ID, subjectId)
        }
        return PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
