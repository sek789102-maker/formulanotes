package com.CHANGE_ME.formulanotes.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.CHANGE_ME.formulanotes.data.model.FocusPreset
import com.CHANGE_ME.formulanotes.data.model.NoteSortOrder
import com.CHANGE_ME.formulanotes.data.model.SubjectCategory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "student_note_prefs")

data class UserPreferences(
    val darkMode: Boolean = false,
    val defaultPaperStyle: Int = 0,
    val sortOrder: NoteSortOrder = NoteSortOrder.UPDATED_DESC,
    val examNotificationsEnabled: Boolean = true,
    val lastBackupExportedAtMillis: Long = 0L,
    val backupReminderDismissedUntilMillis: Long = 0L
)

data class PersistedFocusTimer(
    val preset: FocusPreset = FocusPreset.FOCUS_25,
    val subjectId: String = SubjectCategory.MATH.name,
    val endAtMillis: Long = 0L,
    val pausedRemainingSeconds: Int = -1
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val DARK_MODE = booleanPreferencesKey("dark_mode")
        val DEFAULT_PAPER_STYLE = intPreferencesKey("default_paper_style")
        val SORT_ORDER = stringPreferencesKey("note_sort_order")
        val EXAM_NOTIFICATIONS_ENABLED = booleanPreferencesKey("exam_notifications_enabled")
        val LAST_BACKUP_EXPORTED_AT = longPreferencesKey("last_backup_exported_at_millis")
        val BACKUP_REMINDER_DISMISSED_UNTIL = longPreferencesKey("backup_reminder_dismissed_until_millis")
        val FOCUS_PRESET = stringPreferencesKey("focus_preset")
        val FOCUS_SUBJECT = stringPreferencesKey("focus_subject")
        val FOCUS_END_AT_MILLIS = longPreferencesKey("focus_end_at_millis")
        val FOCUS_PAUSED_REMAINING_SEC = intPreferencesKey("focus_paused_remaining_sec")
    }

    val preferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        UserPreferences(
            darkMode = prefs[Keys.DARK_MODE] ?: false,
            defaultPaperStyle = prefs[Keys.DEFAULT_PAPER_STYLE] ?: 0,
            sortOrder = NoteSortOrder.fromName(prefs[Keys.SORT_ORDER]),
            examNotificationsEnabled = prefs[Keys.EXAM_NOTIFICATIONS_ENABLED] ?: true,
            lastBackupExportedAtMillis = prefs[Keys.LAST_BACKUP_EXPORTED_AT] ?: 0L,
            backupReminderDismissedUntilMillis = prefs[Keys.BACKUP_REMINDER_DISMISSED_UNTIL] ?: 0L
        )
    }

    val focusTimerFlow: Flow<PersistedFocusTimer> = context.dataStore.data.map { prefs ->
        PersistedFocusTimer(
            preset = FocusPreset.fromName(prefs[Keys.FOCUS_PRESET]),
            subjectId = prefs[Keys.FOCUS_SUBJECT] ?: SubjectCategory.MATH.name,
            endAtMillis = prefs[Keys.FOCUS_END_AT_MILLIS] ?: 0L,
            pausedRemainingSeconds = prefs[Keys.FOCUS_PAUSED_REMAINING_SEC] ?: -1
        )
    }

    suspend fun setDarkMode(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.DARK_MODE] = enabled
        }
    }

    suspend fun setDefaultPaperStyle(style: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.DEFAULT_PAPER_STYLE] = style.coerceIn(0, 2)
        }
    }

    suspend fun setSortOrder(order: NoteSortOrder) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SORT_ORDER] = order.name
        }
    }

    suspend fun setExamNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.EXAM_NOTIFICATIONS_ENABLED] = enabled
        }
    }

    suspend fun setLastBackupExportedAt(timestampMillis: Long) {
        context.dataStore.edit { prefs ->
            prefs[Keys.LAST_BACKUP_EXPORTED_AT] = timestampMillis
            prefs[Keys.BACKUP_REMINDER_DISMISSED_UNTIL] = 0L
        }
    }

    suspend fun dismissBackupReminderUntil(untilMillis: Long) {
        context.dataStore.edit { prefs ->
            prefs[Keys.BACKUP_REMINDER_DISMISSED_UNTIL] = untilMillis
        }
    }

    suspend fun saveRunningTimer(preset: FocusPreset, subjectId: String, endAtMillis: Long) {
        context.dataStore.edit { prefs ->
            prefs[Keys.FOCUS_PRESET] = preset.name
            prefs[Keys.FOCUS_SUBJECT] = subjectId
            prefs[Keys.FOCUS_END_AT_MILLIS] = endAtMillis
            prefs[Keys.FOCUS_PAUSED_REMAINING_SEC] = -1
        }
    }

    suspend fun savePausedTimer(preset: FocusPreset, subjectId: String, remainingSeconds: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.FOCUS_PRESET] = preset.name
            prefs[Keys.FOCUS_SUBJECT] = subjectId
            prefs[Keys.FOCUS_END_AT_MILLIS] = 0L
            prefs[Keys.FOCUS_PAUSED_REMAINING_SEC] = remainingSeconds.coerceAtLeast(0)
        }
    }

    suspend fun saveResetTimer(preset: FocusPreset, subjectId: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.FOCUS_PRESET] = preset.name
            prefs[Keys.FOCUS_SUBJECT] = subjectId
            prefs[Keys.FOCUS_END_AT_MILLIS] = 0L
            prefs[Keys.FOCUS_PAUSED_REMAINING_SEC] = -1
        }
    }

    suspend fun consumeFocusTimerCompletion(expectedEndAtMillis: Long): Boolean {
        if (expectedEndAtMillis <= 0L) return false
        var claimed = false
        context.dataStore.edit { prefs ->
            val currentEnd = prefs[Keys.FOCUS_END_AT_MILLIS] ?: 0L
            if (currentEnd == expectedEndAtMillis) {
                prefs[Keys.FOCUS_END_AT_MILLIS] = 0L
                prefs[Keys.FOCUS_PAUSED_REMAINING_SEC] = -1
                claimed = true
            }
        }
        return claimed
    }
}
