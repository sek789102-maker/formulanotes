package com.CHANGE_ME.formulanotes.data.model

import androidx.annotation.StringRes
import com.CHANGE_ME.formulanotes.R

enum class FocusPreset(
    @param:StringRes val labelRes: Int,
    val minutes: Int,
    val isStudy: Boolean
) {
    FOCUS_25(R.string.focus_preset_25, 25, true),
    FOCUS_45(R.string.focus_preset_45, 45, true),
    SHORT_BREAK(R.string.focus_preset_short_break, 5, false),
    LONG_BREAK(R.string.focus_preset_long_break, 15, false);

    companion object {
        fun fromName(name: String?): FocusPreset {
            return entries.firstOrNull { it.name == name } ?: FOCUS_25
        }
    }
}
