package com.CHANGE_ME.formulanotes.data.model

import java.util.UUID

data class FormulaBlock(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val expression: String = "",
    val variablesNote: String = "",
    val mastered: Boolean = false,
    val repetitions: Int = 0,
    val intervalDays: Int = 0,
    val easeFactor: Double = 2.5,
    val nextReviewAtMillis: Long = 0L,
    val lastReviewedAtMillis: Long = 0L
)
