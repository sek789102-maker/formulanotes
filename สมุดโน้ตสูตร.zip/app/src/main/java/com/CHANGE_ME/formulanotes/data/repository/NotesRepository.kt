package com.CHANGE_ME.formulanotes.data.repository

import android.content.Context
import androidx.room.withTransaction
import com.CHANGE_ME.formulanotes.data.local.AppDatabase
import com.CHANGE_ME.formulanotes.data.local.NoteDao
import com.CHANGE_ME.formulanotes.data.model.ExamCountdownEntity
import com.CHANGE_ME.formulanotes.data.model.FormulaBlock
import com.CHANGE_ME.formulanotes.data.model.NoteEntity
import com.CHANGE_ME.formulanotes.data.model.NoteWithTags
import com.CHANGE_ME.formulanotes.data.model.StudySessionEntity
import com.CHANGE_ME.formulanotes.data.model.SubjectCategory
import com.CHANGE_ME.formulanotes.data.model.SubjectEntity
import com.CHANGE_ME.formulanotes.data.model.TagEntity
import com.CHANGE_ME.formulanotes.data.model.TagWithCount
import com.CHANGE_ME.formulanotes.domain.markdown.SimpleMarkdown
import com.CHANGE_ME.formulanotes.domain.study.Sm2Rating
import com.CHANGE_ME.formulanotes.domain.study.Sm2Scheduler
import com.CHANGE_ME.formulanotes.util.NoteImageStorage
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

data class BackupImportSummary(
    val importedNotes: Int,
    val skippedNotes: Int,
    val importedExams: Int,
    val skippedExams: Int,
    val importedSessions: Int,
    val skippedSessions: Int,
    val importedSubjects: Int = 0
) {
    val totalImported: Int get() = importedNotes + importedExams + importedSessions + importedSubjects
    val totalSkipped: Int get() = skippedNotes + skippedExams + skippedSessions
}

class InvalidBackupFormatException : IllegalArgumentException("Invalid backup JSON format")

class NotesRepository(
    private val appContext: Context,
    private val database: AppDatabase
) {

    private val noteDao: NoteDao = database.noteDao()

    val allNotesWithTags: Flow<List<NoteWithTags>> = noteDao.observeAllNotesWithTags()
    val trashedNotesWithTags: Flow<List<NoteWithTags>> = noteDao.observeTrashedNotesWithTags()
    val allTagsWithCount: Flow<List<TagWithCount>> = noteDao.observeTagsWithCount()
    val allTags: Flow<List<TagEntity>> = noteDao.observeAllTags()
    val allSubjects: Flow<List<SubjectEntity>> = noteDao.observeAllSubjects()
    val allExams: Flow<List<ExamCountdownEntity>> = noteDao.observeAllExams()
    val allStudySessions: Flow<List<StudySessionEntity>> = noteDao.observeAllStudySessions()

    fun observeNoteById(noteId: Long): Flow<NoteWithTags?> = noteDao.observeNoteWithTagsById(noteId)

    suspend fun getNoteSnapshot(noteId: Long): NoteWithTags? = noteDao.getNoteWithTagsById(noteId)

    suspend fun saveNote(
        existingId: Long,
        title: String,
        subjectId: String,
        content: String,
        formulas: List<FormulaBlock>,
        imagePaths: List<String>,
        tagIds: List<Long>,
        isPinned: Boolean,
        needsReview: Boolean,
        paperStyle: Int,
        createdAt: Long? = null,
        updatedAt: Long? = null,
        deletedAt: Long? = null
    ): Long {
        val now = System.currentTimeMillis()
        val cleanFormulas = formulas
            .filter { it.title.isNotBlank() || it.expression.isNotBlank() || it.variablesNote.isNotBlank() }
        val note = NoteEntity(
            id = existingId,
            title = title.trim(),
            subject = subjectId,
            content = content,
            formulas = cleanFormulas,
            imagePaths = imagePaths.distinct(),
            isPinned = isPinned,
            needsReview = needsReview,
            paperStyle = paperStyle,
            createdAt = createdAt ?: now,
            updatedAt = updatedAt ?: now,
            deletedAt = deletedAt
        )
        return noteDao.saveNoteWithTags(note, tagIds)
    }

    suspend fun restoreNoteSnapshot(snapshot: NoteWithTags): Long {
        return database.withTransaction {
            val tagIds = buildList {
                for (tag in snapshot.tags) {
                    val clean = tag.name.trim()
                    if (clean.isNotEmpty()) {
                        val tid = noteDao.getOrCreateTag(clean, tag.colorIndex)
                        if (tid > 0L) add(tid)
                    }
                }
            }
            noteDao.restoreNoteWithTags(snapshot.note.copy(deletedAt = null), tagIds)
        }
    }

    suspend fun softDeleteNote(noteId: Long) {
        noteDao.softDeleteNoteById(noteId, System.currentTimeMillis())
    }

    suspend fun restoreNoteFromTrash(noteId: Long) {
        noteDao.restoreNoteFromTrash(noteId, System.currentTimeMillis())
    }

    suspend fun permanentlyDeleteNote(noteId: Long) {
        val snapshot = noteDao.getNoteWithTagsById(noteId)
        noteDao.permanentlyDeleteNoteById(noteId)
        snapshot?.note?.imagePaths?.let { images ->
            NoteImageStorage.deleteImageFiles(appContext, images)
        }
    }

    suspend fun emptyTrash() {
        val trashed = noteDao.getTrashedNotesSnapshot()
        noteDao.emptyTrashNotes()
        val allImages = trashed.flatMap { it.note.imagePaths }.distinct()
        NoteImageStorage.deleteImageFiles(appContext, allImages)
    }

    suspend fun purgeExpiredTrash(retentionDays: Long = 30L, nowMillis: Long = System.currentTimeMillis()): Int {
        val cutoff = nowMillis - TimeUnit.DAYS.toMillis(retentionDays)
        val expired = noteDao.getExpiredTrashedNotes(cutoff)
        if (expired.isEmpty()) return 0
        noteDao.deleteExpiredTrashedNotes(cutoff)
        val images = expired.flatMap { it.imagePaths }.distinct()
        NoteImageStorage.deleteImageFiles(appContext, images)
        return expired.size
    }

    suspend fun togglePin(noteId: Long, newPinned: Boolean) {
        noteDao.updatePinStatus(noteId, newPinned, System.currentTimeMillis())
    }

    suspend fun toggleNeedsReview(noteId: Long, newNeedsReview: Boolean) {
        noteDao.updateNeedsReviewStatus(noteId, newNeedsReview, System.currentTimeMillis())
    }

    suspend fun toggleChecklistLine(noteId: Long, lineIndex: Int) {
        val noteWithTags = noteDao.getNoteWithTagsById(noteId) ?: return
        val updatedContent = SimpleMarkdown.toggleChecklistLine(noteWithTags.note.content, lineIndex)
        if (updatedContent != noteWithTags.note.content) {
            noteDao.updateContent(noteId, updatedContent, System.currentTimeMillis())
        }
    }

    suspend fun rateFormulaSm2(
        noteId: Long,
        formulaId: String,
        rating: Sm2Rating,
        nowMillis: Long = System.currentTimeMillis()
    ) {
        val noteWithTags = noteDao.getNoteWithTagsById(noteId) ?: return
        val updated = noteWithTags.note.formulas.map { block ->
            if (block.id == formulaId) Sm2Scheduler.scheduleReview(block, rating, nowMillis) else block
        }
        noteDao.updateFormulas(noteId, updated, nowMillis)
    }

    suspend fun toggleFormulaMastered(noteId: Long, formulaId: String) {
        val noteWithTags = noteDao.getNoteWithTagsById(noteId) ?: return
        val now = System.currentTimeMillis()
        val updated = noteWithTags.note.formulas.map { block ->
            if (block.id == formulaId) {
                val nextRating = if (block.mastered) Sm2Rating.HARD else Sm2Rating.GOOD
                Sm2Scheduler.scheduleReview(block, nextRating, now)
            } else {
                block
            }
        }
        noteDao.updateFormulas(noteId, updated, now)
    }

    // Tags
    suspend fun createOrGetTag(name: String, colorIndex: Int): Long {
        val clean = name.trim().removePrefix("#").trim()
        require(clean.isNotEmpty()) { "Tag name must not be empty" }
        return noteDao.getOrCreateTag(clean, colorIndex)
    }

    suspend fun updateTag(tag: TagEntity) {
        val clean = tag.name.trim().removePrefix("#").trim()
        if (clean.isNotEmpty()) {
            noteDao.updateTag(tag.copy(name = clean))
        }
    }

    suspend fun deleteTag(tagId: Long) {
        noteDao.deleteTagById(tagId)
    }

    // Subjects (Built-in + User Custom Subjects)
    suspend fun createCustomSubject(name: String, colorHex: Long): SubjectEntity {
        val clean = name.trim()
        require(clean.isNotEmpty()) { "Subject name must not be empty" }
        val existing = noteDao.findSubjectByName(clean)
        if (existing != null) return existing
        val nextSort = noteDao.getMaxSubjectSortOrder() + 1
        val entity = SubjectEntity(
            id = "custom_${UUID.randomUUID().toString().take(8)}",
            name = clean,
            colorHex = colorHex,
            isDefault = false,
            sortOrder = nextSort,
            createdAt = System.currentTimeMillis()
        )
        noteDao.insertSubject(entity)
        return entity
    }

    suspend fun updateCustomSubject(subject: SubjectEntity) {
        val clean = subject.name.trim()
        if (clean.isNotEmpty() && !subject.isDefault) {
            noteDao.updateSubject(subject.copy(name = clean))
        }
    }

    suspend fun deleteCustomSubject(subjectId: String) {
        noteDao.deleteCustomSubjectSafely(subjectId)
    }

    // Exam Countdowns
    suspend fun addExam(title: String, subjectId: String, examDateMillis: Long, note: String): Long {
        return noteDao.insertExam(
            ExamCountdownEntity(
                title = title.trim(),
                subject = subjectId,
                examDateMillis = examDateMillis,
                note = note.trim()
            )
        )
    }

    suspend fun deleteExam(examId: Long) {
        noteDao.deleteExamById(examId)
    }

    suspend fun getAllExamsSnapshot(): List<ExamCountdownEntity> = noteDao.getAllExamsSnapshot()

    // Study Focus Sessions
    suspend fun recordStudySession(subjectId: String, durationMinutes: Int): Long {
        return noteDao.insertStudySession(
            StudySessionEntity(
                subject = subjectId,
                durationMinutes = durationMinutes
            )
        )
    }

    suspend fun exportBackupJson(): String {
        val snapshot = noteDao.getAllNotesWithTagsSnapshot()
        val subjectsSnapshot = noteDao.getAllSubjectsSnapshot()
        val examsSnapshot = noteDao.getAllExamsSnapshot()
        val sessionsSnapshot = noteDao.getAllStudySessionsSnapshot()

        val root = JSONObject()
        root.put("app", "SmutNoteFormula")
        root.put("version", BACKUP_VERSION)
        root.put("exportedAt", System.currentTimeMillis())

        val subjectsArray = JSONArray()
        for (s in subjectsSnapshot) {
            subjectsArray.put(
                JSONObject().apply {
                    put("id", s.id)
                    put("name", s.name)
                    put("colorHex", s.colorHex)
                    put("isDefault", s.isDefault)
                    put("sortOrder", s.sortOrder)
                    put("createdAt", s.createdAt)
                }
            )
        }
        root.put("subjects", subjectsArray)

        val embeddedImages = JSONObject()
        val notesArray = JSONArray()
        for (item in snapshot) {
            val n = item.note
            val noteObj = JSONObject().apply {
                put("title", n.title)
                put("subject", n.subject)
                put("content", n.content)
                put("isPinned", n.isPinned)
                put("needsReview", n.needsReview)
                put("paperStyle", n.paperStyle)
                put("createdAt", n.createdAt)
                put("updatedAt", n.updatedAt)
                if (n.deletedAt != null) {
                    put("deletedAt", n.deletedAt)
                }

                val imgArr = JSONArray()
                for (imgName in n.imagePaths) {
                    imgArr.put(imgName)
                    if (!embeddedImages.has(imgName)) {
                        NoteImageStorage.encodeImageBase64(appContext, imgName)?.let { b64 ->
                            embeddedImages.put(imgName, b64)
                        }
                    }
                }
                put("imagePaths", imgArr)

                val formulasArr = JSONArray()
                for (f in n.formulas) {
                    formulasArr.put(
                        JSONObject().apply {
                            put("id", f.id)
                            put("title", f.title)
                            put("expression", f.expression)
                            put("variablesNote", f.variablesNote)
                            put("mastered", f.mastered)
                            put("repetitions", f.repetitions)
                            put("intervalDays", f.intervalDays)
                            put("easeFactor", f.easeFactor)
                            put("nextReviewAtMillis", f.nextReviewAtMillis)
                            put("lastReviewedAtMillis", f.lastReviewedAtMillis)
                        }
                    )
                }
                put("formulas", formulasArr)

                val tagsArr = JSONArray()
                for (t in item.tags) {
                    tagsArr.put(
                        JSONObject().apply {
                            put("name", t.name)
                            put("colorIndex", t.colorIndex)
                        }
                    )
                }
                put("tags", tagsArr)
            }
            notesArray.put(noteObj)
        }
        root.put("notes", notesArray)
        root.put("embedded_images", embeddedImages)

        val examsArray = JSONArray()
        for (exam in examsSnapshot) {
            examsArray.put(
                JSONObject().apply {
                    put("title", exam.title)
                    put("subject", exam.subject)
                    put("examDateMillis", exam.examDateMillis)
                    put("note", exam.note)
                    put("createdAt", exam.createdAt)
                }
            )
        }
        root.put("exam_countdowns", examsArray)

        val sessionsArray = JSONArray()
        for (session in sessionsSnapshot) {
            sessionsArray.put(
                JSONObject().apply {
                    put("subject", session.subject)
                    put("durationMinutes", session.durationMinutes)
                    put("completedAt", session.completedAt)
                }
            )
        }
        root.put("study_sessions", sessionsArray)

        return root.toString(2)
    }

    suspend fun importBackupJson(rawJson: String): Result<BackupImportSummary> {
        return try {
            val root = JSONObject(rawJson)
            val notesArray = root.optJSONArray("notes")
                ?: return Result.failure(InvalidBackupFormatException())

            val subjectsArray = root.optJSONArray("subjects")
            val embeddedImages = root.optJSONObject("embedded_images")
            val examsArray = root.optJSONArray("exam_countdowns") ?: root.optJSONArray("exams")
            val sessionsArray = root.optJSONArray("study_sessions") ?: root.optJSONArray("studySessions")

            val summary = database.withTransaction {
                var importedSubjects = 0
                if (subjectsArray != null) {
                    for (i in 0 until subjectsArray.length()) {
                        val sObj = subjectsArray.getJSONObject(i)
                        val sId = sObj.optString("id").trim()
                        val sName = sObj.optString("name").trim()
                        if (sId.isEmpty() || sName.isEmpty()) continue
                        if (noteDao.getSubjectById(sId) == null) {
                            noteDao.insertSubject(
                                SubjectEntity(
                                    id = sId,
                                    name = sName,
                                    colorHex = sObj.optLong("colorHex", 0xFF2563EB),
                                    isDefault = sObj.optBoolean("isDefault", false),
                                    sortOrder = sObj.optInt("sortOrder", 10 + i),
                                    createdAt = sObj.optLong("createdAt", System.currentTimeMillis())
                                )
                            )
                            importedSubjects++
                        }
                    }
                }

                val validSubjectIds = noteDao.getAllSubjectsSnapshot().map { it.id }.toMutableSet()

                var importedNotes = 0
                var skippedNotes = 0
                var importedExams = 0
                var skippedExams = 0
                var importedSessions = 0
                var skippedSessions = 0

                val now = System.currentTimeMillis()
                for (i in 0 until notesArray.length()) {
                    val obj = notesArray.getJSONObject(i)
                    val title = obj.optString("title").trim()
                    if (title.isEmpty()) continue

                    val createdAt = if (obj.has("createdAt")) obj.getLong("createdAt") else now
                    val updatedAt = if (obj.has("updatedAt")) obj.optLong("updatedAt", createdAt) else createdAt

                    if (noteDao.countNotesByTitleAndCreatedAt(title, createdAt) > 0) {
                        skippedNotes++
                        continue
                    }

                    val rawSubject = obj.optString("subject").trim()
                    val subjectId = resolveImportSubjectId(rawSubject, validSubjectIds)
                    val content = obj.optString("content")
                    val isPinned = obj.optBoolean("isPinned", false)
                    val needsReview = obj.optBoolean("needsReview", false)
                    val paperStyle = obj.optInt("paperStyle", 0).coerceIn(0, 2)
                    val deletedAt = if (obj.has("deletedAt") && !obj.isNull("deletedAt")) {
                        obj.optLong("deletedAt")
                    } else null

                    val imgArr = obj.optJSONArray("imagePaths") ?: JSONArray()
                    val imagePaths = buildList {
                        for (m in 0 until imgArr.length()) {
                            val imgName = imgArr.optString(m).trim()
                            if (imgName.isNotEmpty()) {
                                val b64 = embeddedImages?.optString(imgName).orEmpty()
                                if (b64.isNotEmpty()) {
                                    if (NoteImageStorage.restoreImageFromBase64(appContext, imgName, b64)) {
                                        add(imgName)
                                    }
                                } else if (NoteImageStorage.resolveImageFile(appContext, imgName).exists()) {
                                    add(imgName)
                                }
                            }
                        }
                    }

                    val formulasArr = obj.optJSONArray("formulas") ?: JSONArray()
                    val formulas = buildList {
                        for (j in 0 until formulasArr.length()) {
                            val fObj = formulasArr.getJSONObject(j)
                            val mastered = fObj.optBoolean("mastered", false)
                            add(
                                FormulaBlock(
                                    id = fObj.optString("id").ifBlank { UUID.randomUUID().toString() },
                                    title = fObj.optString("title"),
                                    expression = fObj.optString("expression"),
                                    variablesNote = fObj.optString("variablesNote"),
                                    mastered = mastered,
                                    repetitions = fObj.optInt("repetitions", if (mastered) 1 else 0),
                                    intervalDays = fObj.optInt("intervalDays", if (mastered) 6 else 0),
                                    easeFactor = fObj.optDouble("easeFactor", 2.5),
                                    nextReviewAtMillis = fObj.optLong("nextReviewAtMillis", 0L),
                                    lastReviewedAtMillis = fObj.optLong("lastReviewedAtMillis", 0L)
                                )
                            )
                        }
                    }

                    val tagsArr = obj.optJSONArray("tags") ?: JSONArray()
                    val tagIds = buildList {
                        for (k in 0 until tagsArr.length()) {
                            val tObj = tagsArr.getJSONObject(k)
                            val tName = tObj.optString("name").trim()
                            if (tName.isNotEmpty()) {
                                val colorIdx = tObj.optInt("colorIndex", 0)
                                val tid = noteDao.getOrCreateTag(tName, colorIdx)
                                if (tid > 0L) add(tid)
                            }
                        }
                    }

                    saveNote(
                        existingId = 0L,
                        title = title,
                        subjectId = subjectId,
                        content = content,
                        formulas = formulas,
                        imagePaths = imagePaths,
                        tagIds = tagIds,
                        isPinned = isPinned,
                        needsReview = needsReview,
                        paperStyle = paperStyle,
                        createdAt = createdAt,
                        updatedAt = updatedAt,
                        deletedAt = deletedAt
                    )
                    importedNotes++
                }

                if (examsArray != null) {
                    for (i in 0 until examsArray.length()) {
                        val eObj = examsArray.getJSONObject(i)
                        val title = eObj.optString("title").trim()
                        if (title.isEmpty() || !eObj.has("examDateMillis")) continue

                        val examDateMillis = eObj.getLong("examDateMillis")
                        if (noteDao.countExamsByTitleAndDate(title, examDateMillis) > 0) {
                            skippedExams++
                            continue
                        }

                        val subjectId = resolveImportSubjectId(eObj.optString("subject").trim(), validSubjectIds)
                        val noteText = eObj.optString("note").trim()
                        val createdAt = eObj.optLong("createdAt", System.currentTimeMillis())

                        noteDao.insertExam(
                            ExamCountdownEntity(
                                title = title,
                                subject = subjectId,
                                examDateMillis = examDateMillis,
                                note = noteText,
                                createdAt = createdAt
                            )
                        )
                        importedExams++
                    }
                }

                if (sessionsArray != null) {
                    for (i in 0 until sessionsArray.length()) {
                        val sObj = sessionsArray.getJSONObject(i)
                        if (!sObj.has("durationMinutes") || !sObj.has("completedAt")) continue

                        val subjectId = resolveImportSubjectId(sObj.optString("subject").trim(), validSubjectIds)
                        val durationMinutes = sObj.getInt("durationMinutes")
                        val completedAt = sObj.getLong("completedAt")
                        if (durationMinutes <= 0) continue

                        if (noteDao.countStudySessions(subjectId, durationMinutes, completedAt) > 0) {
                            skippedSessions++
                            continue
                        }

                        noteDao.insertStudySession(
                            StudySessionEntity(
                                subject = subjectId,
                                durationMinutes = durationMinutes,
                                completedAt = completedAt
                            )
                        )
                        importedSessions++
                    }
                }

                BackupImportSummary(
                    importedNotes = importedNotes,
                    skippedNotes = skippedNotes,
                    importedExams = importedExams,
                    skippedExams = skippedExams,
                    importedSessions = importedSessions,
                    skippedSessions = skippedSessions,
                    importedSubjects = importedSubjects
                )
            }
            Result.success(summary)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun resolveImportSubjectId(rawSubject: String, validIds: Set<String>): String {
        if (rawSubject in validIds) return rawSubject
        return SubjectCategory.fromName(rawSubject).name
    }

    companion object {
        const val BACKUP_VERSION = 3
    }
}
