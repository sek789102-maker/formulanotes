package com.CHANGE_ME.formulanotes.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.CHANGE_ME.formulanotes.R
import com.CHANGE_ME.formulanotes.data.model.StudySessionEntity
import com.CHANGE_ME.formulanotes.data.model.SubjectEntity
import com.CHANGE_ME.formulanotes.data.model.accentStripeColor
import com.CHANGE_ME.formulanotes.data.model.displayName
import com.CHANGE_ME.formulanotes.data.model.resolveSubject
import com.CHANGE_ME.formulanotes.domain.study.StudyStatsCalculator
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudyStatsCard(
    studySessions: List<StudySessionEntity>,
    subjects: List<SubjectEntity>,
    modifier: Modifier = Modifier
) {
    val nowMillis = remember(studySessions.size) { System.currentTimeMillis() }
    val streakDays = remember(studySessions, nowMillis) {
        StudyStatsCalculator.computeReadingStreak(studySessions, nowMillis)
    }
    val bars = remember(studySessions, nowMillis) {
        StudyStatsCalculator.computeLast7DaysStats(studySessions, nowMillis)
    }
    val weeklyMinutes = bars.sumOf { it.totalMinutes }
    val maxDayMinutes = max(30, bars.maxOfOrNull { it.totalMinutes } ?: 0)
    val activeSubjectsInWeek = remember(bars, subjects) {
        bars.flatMap { it.breakdown }
            .map { it.subjectId }
            .distinct()
            .map { subjects.resolveSubject(it) }
    }
    val dayFmt = remember { SimpleDateFormat("EE", Locale.forLanguageTag("th-TH")) }

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(modifier = Modifier.align(Alignment.CenterVertically)) {
                    Text(
                        text = stringResource(R.string.stats_card_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = stringResource(R.string.stats_weekly_total, weeklyMinutes),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (streakDays > 0) Color(0xFFFFEDD5) else MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.align(Alignment.CenterVertically)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.LocalFireDepartment,
                            contentDescription = null,
                            tint = if (streakDays > 0) Color(0xFFEA580C) else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (streakDays > 0) {
                                stringResource(R.string.stats_streak_days, streakDays)
                            } else {
                                stringResource(R.string.stats_streak_zero)
                            },
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (streakDays > 0) Color(0xFF9A3412) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (weeklyMinutes == 0) {
                Text(
                    text = stringResource(R.string.stats_empty_chart),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                // Stacked 7-day Canvas bar chart
                val gridLineColor = MaterialTheme.colorScheme.outlineVariant
                val trackColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                val barColorsByDay = bars.map { bar ->
                    bar.breakdown.map { seg ->
                        subjects.resolveSubject(seg.subjectId).accentStripeColor() to seg.minutes
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        bars.forEach { bar ->
                            Text(
                                text = if (bar.totalMinutes > 0) "${bar.totalMinutes}${stringResource(R.string.stats_minutes_unit)}" else "",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                    ) {
                        val barCount = bars.size
                        val slotWidth = size.width / barCount
                        val barWidth = (slotWidth * 0.56f).coerceAtMost(28.dp.toPx())
                        val corner = CornerRadius(6.dp.toPx(), 6.dp.toPx())

                        // Horizontal baseline
                        drawLine(
                            color = gridLineColor,
                            start = Offset(0f, size.height - 1f),
                            end = Offset(size.width, size.height - 1f),
                            strokeWidth = 1.dp.toPx()
                        )

                        barColorsByDay.forEachIndexed { idx, segments ->
                            val left = idx * slotWidth + (slotWidth - barWidth) / 2f
                            drawRoundRect(
                                color = trackColor,
                                topLeft = Offset(left, 0f),
                                size = Size(barWidth, size.height),
                                cornerRadius = corner
                            )
                            var currentBottom = size.height
                            segments.forEach { (color, mins) ->
                                val segHeight = (mins.toFloat() / maxDayMinutes.toFloat()) * size.height
                                val top = (currentBottom - segHeight).coerceAtLeast(0f)
                                drawRoundRect(
                                    color = color,
                                    topLeft = Offset(left, top),
                                    size = Size(barWidth, currentBottom - top),
                                    cornerRadius = corner
                                )
                                currentBottom = top
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        bars.forEach { bar ->
                            Text(
                                text = dayFmt.format(Date(bar.dayStartMillis)),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                if (activeSubjectsInWeek.isNotEmpty()) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        activeSubjectsInWeek.forEach { subject ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(9.dp)
                                        .clip(CircleShape)
                                        .background(subject.accentStripeColor())
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    text = subject.displayName(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
