package com.CHANGE_ME.formulanotes.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Tag
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.CHANGE_ME.formulanotes.R
import com.CHANGE_ME.formulanotes.data.model.TagEntity
import com.CHANGE_ME.formulanotes.ui.theme.TagTones

@Composable
fun TagPill(
    tag: TagEntity,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    count: Int? = null,
    onClick: (() -> Unit)? = null,
    onRemove: (() -> Unit)? = null
) {
    val tone = TagTones[tag.colorIndex.coerceIn(0, TagTones.lastIndex)]
    val containerColor = if (selected) MaterialTheme.colorScheme.primary else tone.container
    val contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else tone.content

    Surface(
        modifier = modifier.then(
            if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
        ),
        shape = RoundedCornerShape(50),
        color = containerColor,
        border = if (selected) null else BorderStroke(1.dp, tone.content.copy(alpha = 0.18f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.Tag,
                contentDescription = null,
                tint = contentColor,
                modifier = Modifier.size(13.dp)
            )
            Text(
                text = tag.name,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = contentColor
            )
            if (count != null) {
                Text(
                    text = "· $count",
                    style = MaterialTheme.typography.labelSmall,
                    color = contentColor.copy(alpha = 0.78f)
                )
            }
            if (onRemove != null) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = stringResource(R.string.tag_remove_desc, tag.name),
                    tint = contentColor,
                    modifier = Modifier
                        .size(15.dp)
                        .clickable(onClick = onRemove)
                )
            }
        }
    }
}
