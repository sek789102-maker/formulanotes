package com.CHANGE_ME.formulanotes.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.CHANGE_ME.formulanotes.R
import com.CHANGE_ME.formulanotes.data.model.ExamCountdownEntity
import com.CHANGE_ME.formulanotes.data.model.FocusPreset
import com.CHANGE_ME.formulanotes.data.model.StudySessionEntity
import com.CHANGE_ME.formulanotes.data.model.SubjectCategory
import com.CHANGE_ME.formulanotes.data.model.SubjectEntity
import com.CHANGE_ME.formulanotes.data.model.accentStripeColor
import com.CHANGE_ME.formulanotes.data.model.badgeBgColor
import com.CHANGE_ME.formulanotes.data.model.badgeFgColor
import com.CHANGE_ME.formulanotes.data.model.displayName
import com.CHANGE_ME.formulanotes.data.model.resolveSubject
import com.CHANGE_ME.formulanotes.ui.components.EmptyStateView
import com.CHANGE_ME.formulanotes.ui.components.StudentMascotAvatar
import com.CHANGE_ME.formulanotes.ui.components.StudyStatsCard
import com.CHANGE_ME.formulanotes.ui.theme.HeroBlueStart
import com.CHANGE_ME.formulanotes.ui.theme.HeroSkyEnd
import com.CHANGE_ME.formulanotes.ui.theme.JetBrainsMonoFontFamily
import com.CHANGE_ME.formulanotes.ui.theme.PlayfairDisplayFontFamily
import com.CHANGE_ME.formulanotes.ui.viewmodel.FocusTimerState
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FocusAndExamScreen(
    timerState: FocusTimerState,
    studySessions: List<StudySessionEntity>,
    exams: List<ExamCountdownEntity>,
    subjects: List<SubjectEntity>,
    onSelectPreset: (FocusPreset) -> Unit,
    onSelectSubject: (String) -> Unit,
    onToggleTimer: () -> Unit,
    onResetTimer: () -> Unit,
    onAddExam: (String, String, Long, String) -> Unit,
    onDeleteExam: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showAddExamDialog by rememberSaveable { mutableStateOf(false) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Timer & exam notifications proceed gracefully based on permission status.
    }

    LaunchedEffect(timerState.completedEventCount) {
        if (timerState.completedEventCount > 0) {
            triggerHapticAlert(context)
        }
    }

    val selectedSubject = subjects.resolveSubject(timerState.selectedSubjectId)
    val totalFocusMinutes = studySessions.sumOf { it.durationMinutes }
    val minutes = timerState.remainingSeconds / 60
    val seconds = timerState.remainingSeconds % 60
    val timeText = String.format(Locale.US, "%02d:%02d", minutes, seconds)
    val progress = if (timerState.totalSeconds > 0) {
        1f - (timerState.remainingSeconds.toFloat() / timerState.totalSeconds.toFloat())
    } else 0f

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header with Student Mascot
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    StudentMascotAvatar(sizeDp = 50)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = stringResource(R.string.focus_header_title),
                            fontFamily = PlayfairDisplayFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 23.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = if (timerState.isRunning) {
                                stringResource(
                                    R.string.focus_running_subtitle,
                                    selectedSubject.displayName()
                                )
                            } else {
                                stringResource(R.string.focus_idle_subtitle, totalFocusMinutes, studySessions.size)
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.width(8.dp))
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Timer,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Pomodoro",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            // Pomodoro Timer Gradient Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(26.dp))
                    .background(Brush.linearGradient(listOf(HeroBlueStart, HeroSkyEnd)))
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FocusPreset.entries.forEach { preset ->
                            val selected = timerState.preset == preset
                            Surface(
                                onClick = { onSelectPreset(preset) },
                                shape = RoundedCornerShape(50),
                                color = if (selected) Color.White else Color.White.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = stringResource(preset.labelRes),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (selected) HeroBlueStart else Color.White,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }

                    // Circular Countdown Ring
                    Box(
                        modifier = Modifier.size(178.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val strokeWidth = 12.dp.toPx()
                            drawArc(
                                color = Color.White.copy(alpha = 0.22f),
                                startAngle = 0f,
                                sweepAngle = 360f,
                                useCenter = false,
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                            drawArc(
                                color = Color.White,
                                startAngle = -90f,
                                sweepAngle = 360f * progress,
                                useCenter = false,
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                        }
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(horizontal = 14.dp)
                        ) {
                            Text(
                                text = timeText,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 36.sp,
                                color = Color.White
                            )
                            Text(
                                text = if (timerState.preset.isStudy) {
                                    stringResource(
                                        R.string.focus_subject_label,
                                        selectedSubject.displayName()
                                    )
                                } else {
                                    stringResource(R.string.focus_break_label)
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        }
                    }

                    if (timerState.preset.isStudy) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            subjects.forEach { cat ->
                                val selected = timerState.selectedSubjectId == cat.id
                                Surface(
                                    onClick = { onSelectSubject(cat.id) },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (selected) Color.White else Color.White.copy(alpha = 0.16f)
                                ) {
                                    Text(
                                        text = cat.displayName(),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (selected) cat.badgeFgColor() else Color.White,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (!timerState.isRunning && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    val granted = ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.POST_NOTIFICATIONS
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (!granted) {
                                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                }
                                onToggleTimer()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = HeroBlueStart
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.testTag("focus_start_pause_button")
                        ) {
                            Icon(
                                imageVector = if (timerState.isRunning) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                contentDescription = null
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = stringResource(if (timerState.isRunning) R.string.focus_pause else R.string.focus_start),
                                fontWeight = FontWeight.Bold
                            )
                        }
                        OutlinedButton(
                            onClick = onResetTimer,
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.7f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(stringResource(R.string.focus_reset))
                        }
                    }
                }
            }

            // 7-Day Reading Stats & Consecutive Streak Card (Feature 10)
            StudyStatsCard(
                studySessions = studySessions,
                subjects = subjects
            )

            // Exam Countdown Section
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.exam_section_title),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = stringResource(R.string.exam_total_count, exams.size),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = { showAddExamDialog = true },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("add_exam_button")
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(stringResource(R.string.exam_add_button), maxLines = 1, softWrap = false)
                }
            }

            if (exams.isEmpty()) {
                EmptyStateView(
                    title = stringResource(R.string.empty_exams_title),
                    subtitle = stringResource(R.string.empty_exams_subtitle),
                    showIllustration = false,
                    actionLabel = stringResource(R.string.exam_add_first),
                    onAction = { showAddExamDialog = true }
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    exams.forEach { exam ->
                        ExamCountdownCard(
                            exam = exam,
                            subject = subjects.resolveSubject(exam.subject),
                            onDelete = { onDeleteExam(exam.id) }
                        )
                    }
                }
            }

            Spacer(Modifier.height(72.dp))
        }
    }

    if (showAddExamDialog) {
        AddExamDialog(
            subjects = subjects,
            onDismiss = { showAddExamDialog = false },
            onConfirm = { title, subjectId, dateMillis, note ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val granted = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_GRANTED
                    if (!granted) {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
                onAddExam(title, subjectId, dateMillis, note)
                showAddExamDialog = false
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ExamCountdownCard(
    exam: ExamCountdownEntity,
    subject: SubjectEntity,
    onDelete: () -> Unit
) {
    val daysRemaining = remember(exam.examDateMillis) {
        val calNow = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val calTarget = Calendar.getInstance().apply {
            timeInMillis = exam.examDateMillis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        TimeUnit.MILLISECONDS.toDays(calTarget.timeInMillis - calNow.timeInMillis).toInt()
    }
    val dateLabel = SimpleDateFormat("d MMM yyyy", Locale.forLanguageTag("th-TH")).format(Date(exam.examDateMillis))
    val countdownBadgeBg = when {
        daysRemaining < 0 -> MaterialTheme.colorScheme.surfaceVariant
        daysRemaining <= 3 -> Color(0xFFFFE4E6)
        daysRemaining <= 7 -> Color(0xFFFEF3C7)
        else -> MaterialTheme.colorScheme.primaryContainer
    }
    val countdownBadgeFg = when {
        daysRemaining < 0 -> MaterialTheme.colorScheme.onSurfaceVariant
        daysRemaining <= 3 -> Color(0xFFBE123C)
        daysRemaining <= 7 -> Color(0xFFB45309)
        else -> MaterialTheme.colorScheme.primary
    }
    val countdownText = when {
        daysRemaining < 0 -> stringResource(R.string.exam_days_past, -daysRemaining)
        daysRemaining == 0 -> stringResource(R.string.exam_days_today)
        else -> stringResource(R.string.exam_days_left, daysRemaining)
    }

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = subject.badgeBgColor(),
                        modifier = Modifier.align(Alignment.CenterVertically)
                    ) {
                        Text(
                            text = subject.displayName(),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = subject.badgeFgColor(),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.align(Alignment.CenterVertically)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Event,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = dateLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Text(
                    text = exam.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (exam.note.isNotBlank()) {
                    Text(
                        text = exam.note,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.width(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = countdownBadgeBg
                ) {
                    Text(
                        text = countdownText,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = countdownBadgeFg,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteOutline,
                        contentDescription = stringResource(R.string.exam_delete_desc),
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddExamDialog(
    subjects: List<SubjectEntity>,
    onDismiss: () -> Unit,
    onConfirm: (String, String, Long, String) -> Unit
) {
    var title by rememberSaveable { mutableStateOf("") }
    var selectedSubjectId by rememberSaveable { mutableStateOf(SubjectCategory.MATH.name) }
    var note by rememberSaveable { mutableStateOf("") }
    var selectedDateMillis by rememberSaveable {
        mutableLongStateOf(System.currentTimeMillis() + TimeUnit.DAYS.toMillis(7))
    }
    var showDatePicker by rememberSaveable { mutableStateOf(false) }

    val dateFormatted = SimpleDateFormat("d MMMM yyyy", Locale.forLanguageTag("th-TH")).format(Date(selectedDateMillis))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.exam_dialog_title)) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(stringResource(R.string.exam_dialog_name_label)) },
                    placeholder = { Text(stringResource(R.string.exam_dialog_name_placeholder)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    subjects.forEach { cat ->
                        FilterChip(
                            selected = selectedSubjectId == cat.id,
                            onClick = { selectedSubjectId = cat.id },
                            label = { Text(cat.displayName()) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = cat.accentStripeColor(),
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
                OutlinedButton(
                    onClick = { showDatePicker = true },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.CalendarMonth, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.exam_dialog_date_label, dateFormatted))
                }
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text(stringResource(R.string.exam_dialog_note_label)) },
                    placeholder = { Text(stringResource(R.string.exam_dialog_note_placeholder)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(title, selectedSubjectId, selectedDateMillis, note) },
                enabled = title.trim().isNotEmpty()
            ) {
                Text(stringResource(R.string.action_save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
        }
    )

    if (showDatePicker) {
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = selectedDateMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { selectedDateMillis = it }
                        showDatePicker = false
                    }
                ) { Text(stringResource(R.string.action_choose)) }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}

@Suppress("DEPRECATION")
private fun triggerHapticAlert(context: Context) {
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            manager?.defaultVibrator?.vibrate(
                VibrationEffect.createOneShot(400L, VibrationEffect.DEFAULT_AMPLITUDE)
            )
        } else {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(400L, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                vibrator?.vibrate(400L)
            }
        }
    } catch (_: Exception) {
    }
}
