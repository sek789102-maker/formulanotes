package com.CHANGE_ME.formulanotes.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.EventAvailable
import androidx.compose.material.icons.rounded.Flip
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.CHANGE_ME.formulanotes.R
import com.CHANGE_ME.formulanotes.data.model.FormulaBlock
import com.CHANGE_ME.formulanotes.data.model.SubjectEntity
import com.CHANGE_ME.formulanotes.data.model.accentStripeColor
import com.CHANGE_ME.formulanotes.data.model.badgeBgColor
import com.CHANGE_ME.formulanotes.data.model.badgeFgColor
import com.CHANGE_ME.formulanotes.data.model.displayName
import com.CHANGE_ME.formulanotes.data.model.resolveSubject
import com.CHANGE_ME.formulanotes.domain.study.Sm2Rating
import com.CHANGE_ME.formulanotes.domain.study.Sm2Scheduler
import com.CHANGE_ME.formulanotes.ui.components.EmptyStateView
import com.CHANGE_ME.formulanotes.ui.components.FormulaEvaluatorDialog
import com.CHANGE_ME.formulanotes.ui.components.TagPill
import com.CHANGE_ME.formulanotes.ui.theme.JetBrainsMonoFontFamily
import com.CHANGE_ME.formulanotes.ui.theme.PlayfairDisplayFontFamily
import com.CHANGE_ME.formulanotes.ui.viewmodel.StudyFormulaItem
import java.util.concurrent.TimeUnit

private enum class StudyMode {
    FLASHCARD,
    QUIZ
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FormulaStudyScreen(
    studyFormulas: List<StudyFormulaItem>,
    subjects: List<SubjectEntity>,
    onRateFormulaSm2: (Long, String, Sm2Rating) -> Unit,
    onCreateNote: () -> Unit,
    onOpenNote: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var studyModeName by rememberSaveable { mutableStateOf(StudyMode.FLASHCARD.name) }
    val studyMode = StudyMode.entries.firstOrNull { it.name == studyModeName } ?: StudyMode.FLASHCARD

    var selectedSubjectId by rememberSaveable { mutableStateOf<String?>(null) }
    var onlyDueToday by rememberSaveable { mutableStateOf(false) }
    var onlyUnmastered by rememberSaveable { mutableStateOf(false) }
    var currentIndex by rememberSaveable { mutableIntStateOf(0) }
    var isFlipped by rememberSaveable { mutableStateOf(false) }
    var evalFormula by remember { mutableStateOf<FormulaBlock?>(null) }

    // Quiz state
    var quizRound by rememberSaveable { mutableIntStateOf(0) }
    var quizScore by rememberSaveable { mutableIntStateOf(0) }
    var quizStreak by rememberSaveable { mutableIntStateOf(0) }
    var selectedAnswerIndex by rememberSaveable { mutableIntStateOf(-1) }

    val endOfTodayMillis = remember(studyFormulas.size) { Sm2Scheduler.endOfDayMillis() }
    val dueTodayCount = remember(studyFormulas, endOfTodayMillis) {
        studyFormulas.count { Sm2Scheduler.isDueForReview(it.formula, endOfTodayMillis) }
    }

    val filtered = remember(studyFormulas, selectedSubjectId, onlyDueToday, onlyUnmastered, endOfTodayMillis) {
        studyFormulas.filter { item ->
            (selectedSubjectId == null || item.subjectId == selectedSubjectId) &&
                (!onlyDueToday || Sm2Scheduler.isDueForReview(item.formula, endOfTodayMillis)) &&
                (!onlyUnmastered || !item.formula.mastered)
        }
    }

    val safeIndex = if (filtered.isEmpty()) 0 else currentIndex.coerceIn(0, filtered.lastIndex)
    val masteredCount = studyFormulas.count { it.formula.mastered }

    Column(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(modifier = Modifier.align(Alignment.CenterVertically)) {
                    Text(
                        text = stringResource(R.string.nav_study),
                        fontFamily = PlayfairDisplayFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 26.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = stringResource(R.string.study_mastered_progress, masteredCount, studyFormulas.size),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (studyFormulas.isNotEmpty()) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.align(Alignment.CenterVertically)
                    ) {
                        FilterChip(
                            selected = studyMode == StudyMode.FLASHCARD,
                            onClick = { studyModeName = StudyMode.FLASHCARD.name },
                            label = { Text(stringResource(R.string.study_mode_cards)) },
                            leadingIcon = {
                                Icon(Icons.Rounded.Style, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        )
                        FilterChip(
                            selected = studyMode == StudyMode.QUIZ,
                            onClick = {
                                studyModeName = StudyMode.QUIZ.name
                                selectedAnswerIndex = -1
                            },
                            label = { Text(stringResource(R.string.study_mode_quiz)) },
                            leadingIcon = {
                                Icon(Icons.Rounded.Quiz, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        )
                    }
                }
            }

            if (studyFormulas.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { masteredCount.toFloat() / studyFormulas.size.toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp),
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(Modifier.height(10.dp))
                // SM-2 Today's Review Due Banner (Feature 8)
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (dueTodayCount > 0) {
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f)
                    } else {
                        Color(0xFFD1FAE5)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = if (dueTodayCount > 0) Icons.Rounded.EventAvailable else Icons.Rounded.CheckCircle,
                            contentDescription = null,
                            tint = if (dueTodayCount > 0) MaterialTheme.colorScheme.primary else Color(0xFF047857),
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = if (dueTodayCount > 0) {
                                stringResource(R.string.study_due_today_banner, dueTodayCount)
                            } else {
                                stringResource(R.string.study_due_today_done)
                            },
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = if (dueTodayCount > 0) MaterialTheme.colorScheme.onPrimaryContainer else Color(0xFF065F46)
                        )
                    }
                }
            }
        }

        if (studyFormulas.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                EmptyStateView(
                    title = stringResource(R.string.empty_study_title),
                    subtitle = stringResource(R.string.empty_study_subtitle),
                    showIllustration = false,
                    useMascotIllustration = true,
                    actionLabel = stringResource(R.string.action_new_note),
                    onAction = onCreateNote
                )
            }
        } else if (studyMode == StudyMode.QUIZ) {
            val quizQuestionItem = studyFormulas[quizRound % studyFormulas.size]
            val quizSubject = subjects.resolveSubject(quizQuestionItem.subjectId)
            val choices = remember(quizRound, studyFormulas) {
                val correctExpr = quizQuestionItem.formula.expression
                val distractors = studyFormulas
                    .map { it.formula.expression }
                    .distinct()
                    .filter { it != correctExpr }
                    .shuffled()
                    .take(3)
                (listOf(correctExpr) + distractors).shuffled()
            }
            val correctChoiceIdx = choices.indexOf(quizQuestionItem.formula.expression)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Column(
                    modifier = Modifier.widthIn(max = 560.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        FlowRow(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.align(Alignment.CenterVertically)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.EmojiEvents,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = stringResource(R.string.quiz_score, quizScore),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                            Text(
                                text = stringResource(R.string.quiz_streak, quizStreak),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.align(Alignment.CenterVertically)
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = quizSubject.badgeBgColor()
                            ) {
                                Text(
                                    text = quizSubject.displayName(),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = quizSubject.badgeFgColor(),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Text(
                                text = stringResource(R.string.quiz_question_prompt),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = quizQuestionItem.formula.title.ifBlank { quizQuestionItem.noteTitle },
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (quizQuestionItem.formula.variablesNote.isNotBlank()) {
                                Text(
                                    text = stringResource(
                                        R.string.quiz_hint_prefix,
                                        quizQuestionItem.formula.variablesNote
                                    ),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    if (choices.size < 2) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = stringResource(R.string.quiz_need_more_formulas),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    choices.forEachIndexed { idx, expr ->
                        val answered = selectedAnswerIndex != -1
                        val isCorrect = idx == correctChoiceIdx
                        val isSelected = idx == selectedAnswerIndex
                        val bg = when {
                            !answered -> MaterialTheme.colorScheme.surface
                            isCorrect -> Color(0xFFD1FAE5)
                            isSelected -> Color(0xFFFFE4E6)
                            else -> MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
                        }
                        val borderColor = when {
                            !answered -> MaterialTheme.colorScheme.outlineVariant
                            isCorrect -> Color(0xFF059669)
                            isSelected -> Color(0xFFE11D48)
                            else -> MaterialTheme.colorScheme.outlineVariant
                        }
                        val textColor = when {
                            !answered -> MaterialTheme.colorScheme.onSurface
                            isCorrect -> Color(0xFF065F46)
                            isSelected -> Color(0xFF9F1239)
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }

                        Surface(
                            onClick = {
                                if (!answered) {
                                    selectedAnswerIndex = idx
                                    if (isCorrect) {
                                        quizScore++
                                        quizStreak++
                                    } else {
                                        quizStreak = 0
                                    }
                                }
                            },
                            shape = RoundedCornerShape(16.dp),
                            color = bg,
                            border = BorderStroke(1.5.dp, borderColor),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = expr,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = textColor,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp)
                            )
                        }
                    }

                    if (selectedAnswerIndex != -1) {
                        Button(
                            onClick = {
                                quizRound++
                                selectedAnswerIndex = -1
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(stringResource(R.string.quiz_next_question))
                        }
                    }

                    Spacer(Modifier.height(24.dp))
                }
            }
        } else {
            // Flashcard Mode with SM-2 Filters & Rating
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = onlyDueToday,
                    onClick = {
                        onlyDueToday = !onlyDueToday
                        currentIndex = 0
                        isFlipped = false
                    },
                    label = { Text(stringResource(R.string.study_filter_due_today, dueTodayCount)) }
                )
                FilterChip(
                    selected = onlyUnmastered,
                    onClick = {
                        onlyUnmastered = !onlyUnmastered
                        currentIndex = 0
                        isFlipped = false
                    },
                    label = { Text(stringResource(R.string.study_filter_unmastered)) }
                )
                subjects.forEach { cat ->
                    if (studyFormulas.any { it.subjectId == cat.id }) {
                        FilterChip(
                            selected = selectedSubjectId == cat.id,
                            onClick = {
                                selectedSubjectId = if (selectedSubjectId == cat.id) null else cat.id
                                currentIndex = 0
                                isFlipped = false
                            },
                            label = { Text(cat.displayName()) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = cat.accentStripeColor(),
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            if (filtered.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyStateView(
                        title = stringResource(R.string.study_all_reviewed_title),
                        subtitle = stringResource(R.string.study_all_reviewed_subtitle),
                        showIllustration = false,
                        actionLabel = stringResource(R.string.study_show_all_formulas),
                        onAction = {
                            onlyDueToday = false
                            onlyUnmastered = false
                            selectedSubjectId = null
                            currentIndex = 0
                            isFlipped = false
                        }
                    )
                }
            } else {
                val item = filtered[safeIndex]
                val itemSubject = subjects.resolveSubject(item.subjectId)
                val accent = itemSubject.accentStripeColor()
                val rotation by animateFloatAsState(
                    targetValue = if (isFlipped) 180f else 0f,
                    animationSpec = tween(durationMillis = 360),
                    label = "flashcard_flip"
                )

                val hardDays = Sm2Scheduler.previewIntervalDays(item.formula, Sm2Rating.HARD)
                val goodDays = Sm2Scheduler.previewIntervalDays(item.formula, Sm2Rating.GOOD)
                val easyDays = Sm2Scheduler.previewIntervalDays(item.formula, Sm2Rating.EASY)

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        modifier = Modifier.widthIn(max = 520.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = stringResource(R.string.study_card_counter, safeIndex + 1, filtered.size),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(Modifier.height(10.dp))

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 240.dp)
                                .graphicsLayer {
                                    rotationY = rotation
                                    cameraDistance = 14f * density
                                }
                                .clickable { isFlipped = !isFlipped },
                            shape = RoundedCornerShape(26.dp),
                            color = if (rotation <= 90f) {
                                MaterialTheme.colorScheme.surface
                            } else {
                                MaterialTheme.colorScheme.primaryContainer
                            },
                            border = BorderStroke(1.5.dp, accent.copy(alpha = 0.55f)),
                            shadowElevation = 4.dp
                        ) {
                            if (rotation <= 90f) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 240.dp)
                                        .padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = itemSubject.badgeBgColor()
                                        ) {
                                            Text(
                                                text = itemSubject.displayName(),
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = itemSubject.badgeFgColor(),
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                        if (item.formula.nextReviewAtMillis > System.currentTimeMillis()) {
                                            val daysUntil = TimeUnit.MILLISECONDS.toDays(
                                                item.formula.nextReviewAtMillis - Sm2Scheduler.startOfDayMillis()
                                            ).toInt().coerceAtLeast(1)
                                            Text(
                                                text = stringResource(R.string.study_sm2_next_review, daysUntil),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        } else if (item.formula.mastered) {
                                            Icon(
                                                imageVector = Icons.Rounded.CheckCircle,
                                                contentDescription = stringResource(R.string.formula_mastered),
                                                tint = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }

                                    Spacer(Modifier.height(14.dp))

                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = item.formula.title.ifBlank {
                                                stringResource(R.string.study_card_fallback_title, item.noteTitle)
                                            },
                                            style = MaterialTheme.typography.headlineSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            textAlign = TextAlign.Center
                                        )
                                        Spacer(Modifier.height(8.dp))
                                        Text(
                                            text = stringResource(R.string.study_card_from_note, item.noteTitle),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            textAlign = TextAlign.Center
                                        )
                                    }

                                    Spacer(Modifier.height(14.dp))

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Flip,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = stringResource(R.string.study_tap_to_flip),
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            } else {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 240.dp)
                                        .graphicsLayer { rotationY = 180f }
                                        .padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = item.formula.title.ifBlank { item.noteTitle },
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                                        textAlign = TextAlign.Center
                                    )

                                    Spacer(Modifier.height(12.dp))

                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = item.formula.expression,
                                            fontFamily = JetBrainsMonoFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 23.sp,
                                            lineHeight = 31.sp,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            textAlign = TextAlign.Center
                                        )
                                        if (item.formula.variablesNote.isNotBlank()) {
                                            Spacer(Modifier.height(10.dp))
                                            Text(
                                                text = item.formula.variablesNote,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f),
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }

                                    Spacer(Modifier.height(12.dp))

                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = { evalFormula = item.formula },
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(Icons.Rounded.Calculate, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text(stringResource(R.string.study_try_evaluate))
                                        }
                                        OutlinedButton(
                                            onClick = { onOpenNote(item.noteId) },
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Text(stringResource(R.string.study_open_note))
                                        }
                                    }
                                }
                            }
                        }

                        if (item.tags.isNotEmpty()) {
                            Spacer(Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                item.tags.forEach { TagPill(tag = it) }
                            }
                        }

                        Spacer(Modifier.height(14.dp))

                        // SM-2 Rating Controls + Prev/Next
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    currentIndex = if (safeIndex > 0) safeIndex - 1 else filtered.lastIndex
                                    isFlipped = false
                                }
                            ) {
                                Icon(
                                    Icons.AutoMirrored.Rounded.ArrowBack,
                                    contentDescription = stringResource(R.string.study_prev_card)
                                )
                            }

                            Sm2RatingButton(
                                label = stringResource(R.string.study_sm2_hard),
                                days = hardDays,
                                containerColor = Color(0xFFFFE4E6),
                                contentColor = Color(0xFFBE123C),
                                onClick = {
                                    onRateFormulaSm2(item.noteId, item.formula.id, Sm2Rating.HARD)
                                    currentIndex = (safeIndex + 1) % filtered.size
                                    isFlipped = false
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("sm2_hard_button")
                            )

                            Sm2RatingButton(
                                label = stringResource(R.string.study_sm2_good),
                                days = goodDays,
                                containerColor = Color(0xFFDBEAFE),
                                contentColor = Color(0xFF1D4ED8),
                                onClick = {
                                    onRateFormulaSm2(item.noteId, item.formula.id, Sm2Rating.GOOD)
                                    currentIndex = (safeIndex + 1) % filtered.size
                                    isFlipped = false
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("sm2_good_button")
                            )

                            Sm2RatingButton(
                                label = stringResource(R.string.study_sm2_easy),
                                days = easyDays,
                                containerColor = Color(0xFFD1FAE5),
                                contentColor = Color(0xFF047857),
                                onClick = {
                                    onRateFormulaSm2(item.noteId, item.formula.id, Sm2Rating.EASY)
                                    currentIndex = (safeIndex + 1) % filtered.size
                                    isFlipped = false
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("sm2_easy_button")
                            )

                            IconButton(
                                onClick = {
                                    currentIndex = (safeIndex + 1) % filtered.size
                                    isFlipped = false
                                }
                            ) {
                                Icon(
                                    Icons.AutoMirrored.Rounded.ArrowForward,
                                    contentDescription = stringResource(R.string.study_next_card)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    evalFormula?.let { f ->
        FormulaEvaluatorDialog(
            formula = f,
            onDismiss = { evalFormula = null }
        )
    }
}

@Composable
private fun Sm2RatingButton(
    label: String,
    days: Int,
    containerColor: Color,
    contentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Text(
                text = stringResource(R.string.study_sm2_interval_days, days),
                style = MaterialTheme.typography.labelSmall,
                color = contentColor.copy(alpha = 0.85f),
                maxLines = 1
            )
        }
    }
}
