package com.CHANGE_ME.formulanotes.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AddCircle
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Functions
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.ShowChart
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.CHANGE_ME.formulanotes.R
import com.CHANGE_ME.formulanotes.data.model.NoteSortOrder
import com.CHANGE_ME.formulanotes.data.model.NoteWithTags
import com.CHANGE_ME.formulanotes.data.model.SubjectEntity
import com.CHANGE_ME.formulanotes.data.model.TagWithCount
import com.CHANGE_ME.formulanotes.data.model.accentStripeColor
import com.CHANGE_ME.formulanotes.data.model.badgeBgColor
import com.CHANGE_ME.formulanotes.data.model.badgeFgColor
import com.CHANGE_ME.formulanotes.data.model.displayName
import com.CHANGE_ME.formulanotes.data.model.resolveSubject
import com.CHANGE_ME.formulanotes.domain.markdown.SimpleMarkdown
import com.CHANGE_ME.formulanotes.ui.components.CustomSubjectDialog
import com.CHANGE_ME.formulanotes.ui.components.EmptyStateView
import com.CHANGE_ME.formulanotes.ui.components.StudentMascotAvatar
import com.CHANGE_ME.formulanotes.ui.components.TagPill
import com.CHANGE_ME.formulanotes.ui.theme.HeroBlueStart
import com.CHANGE_ME.formulanotes.ui.theme.HeroSkyEnd
import com.CHANGE_ME.formulanotes.ui.theme.JetBrainsMonoFontFamily
import com.CHANGE_ME.formulanotes.ui.theme.PlayfairDisplayFontFamily
import com.CHANGE_ME.formulanotes.ui.viewmodel.FilterState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun NotesHomeScreen(
    allNotesCount: Int,
    totalFormulasCount: Int,
    totalFocusMinutes: Int,
    trashedCount: Int,
    showBackupReminder: Boolean,
    subjects: List<SubjectEntity>,
    tagsWithCount: List<TagWithCount>,
    filteredNotes: List<NoteWithTags>,
    filterState: FilterState,
    sortOrder: NoteSortOrder,
    isWideLayout: Boolean,
    onSearchChange: (String) -> Unit,
    onSelectSubject: (String?) -> Unit,
    onCreateSubject: (String, Long) -> Unit,
    onChangeSortOrder: (NoteSortOrder) -> Unit,
    onToggleTag: (Long) -> Unit,
    onTogglePinnedFilter: () -> Unit,
    onToggleFormulaFilter: () -> Unit,
    onToggleReviewFilter: () -> Unit,
    onClearFilters: () -> Unit,
    onOpenNote: (Long) -> Unit,
    onCreateNote: () -> Unit,
    onQuickOpenStudy: () -> Unit,
    onQuickOpenGraph: () -> Unit,
    onQuickOpenFocus: () -> Unit,
    onTogglePinNote: (Long, Boolean) -> Unit,
    onOpenTrash: () -> Unit,
    onOpenSettings: () -> Unit,
    onBackupNowFromReminder: () -> Unit,
    onDismissBackupReminder: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddSubjectDialog by rememberSaveable { mutableStateOf(false) }
    var showSortMenu by remember { mutableStateOf(false) }

    val mascotSpeech = when {
        allNotesCount == 0 -> stringResource(R.string.mascot_speech_empty)
        totalFormulasCount == 0 -> stringResource(R.string.mascot_speech_no_formula, allNotesCount)
        else -> stringResource(R.string.mascot_speech_active, allNotesCount, totalFormulasCount)
    }

    Column(modifier = modifier.fillMaxSize()) {
        // Vibrant Blue-Sky Gradient Hero Header with Cartoon Student Mascot
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(HeroBlueStart, HeroSkyEnd)
                    )
                )
                .drawBehind {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.14f),
                        radius = size.height * 0.65f,
                        center = Offset(size.width * 0.92f, size.height * 0.15f)
                    )
                    drawCircle(
                        color = Color.White.copy(alpha = 0.08f),
                        radius = size.height * 0.45f,
                        center = Offset(size.width * 0.72f, size.height * 0.95f)
                    )
                }
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StudentMascotAvatar(sizeDp = 58)
                        Spacer(Modifier.width(12.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = stringResource(R.string.app_name),
                                fontFamily = PlayfairDisplayFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 22.sp,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.White.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = mascotSpeech,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.White,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                    Spacer(Modifier.width(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(
                            onClick = onOpenTrash,
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.22f),
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("open_trash_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                BadgedBox(
                                    badge = {
                                        if (trashedCount > 0) {
                                            Badge(containerColor = Color(0xFFEF4444)) {
                                                Text(
                                                    text = trashedCount.coerceAtMost(99).toString(),
                                                    color = Color.White,
                                                    fontSize = 10.sp
                                                )
                                            }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.DeleteOutline,
                                        contentDescription = stringResource(R.string.trash_open_desc),
                                        tint = Color.White
                                    )
                                }
                            }
                        }
                        Surface(
                            onClick = onOpenSettings,
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.22f),
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("open_settings_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Rounded.Settings,
                                    contentDescription = stringResource(R.string.settings_backup_desc),
                                    tint = Color.White
                                )
                            }
                        }
                    }
                }

                // Live 0-based Mini Stat Pills
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HeroStatChip(stringResource(R.string.hero_stat_notes, allNotesCount))
                    HeroStatChip(stringResource(R.string.hero_stat_formulas, totalFormulasCount))
                    HeroStatChip(stringResource(R.string.hero_stat_tags, tagsWithCount.size))
                    HeroStatChip(stringResource(R.string.hero_stat_focus, totalFocusMinutes))
                }
            }
        }

        // 14-day Backup Reminder Banner (Feature 12)
        if (showBackupReminder) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.72f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.3f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .testTag("backup_reminder_banner")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Backup,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.backup_reminder_title),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                        Text(
                            text = stringResource(R.string.backup_reminder_subtitle),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.85f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = onDismissBackupReminder) {
                            Text(stringResource(R.string.backup_reminder_later))
                        }
                        Button(
                            onClick = onBackupNowFromReminder,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(stringResource(R.string.backup_reminder_now))
                        }
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
        }

        // Colorful Quick Launch Student Tools Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QuickShortcutPill(
                label = stringResource(R.string.shortcut_new_note),
                icon = Icons.Rounded.AddCircle,
                bg = Color(0xFFDBEAFE),
                fg = Color(0xFF1D4ED8),
                onClick = onCreateNote
            )
            QuickShortcutPill(
                label = stringResource(R.string.shortcut_quiz),
                icon = Icons.Rounded.Quiz,
                bg = Color(0xFFEDE9FE),
                fg = Color(0xFF6D28D9),
                onClick = onQuickOpenStudy
            )
            QuickShortcutPill(
                label = stringResource(R.string.shortcut_graph),
                icon = Icons.Rounded.ShowChart,
                bg = Color(0xFFCFFAFE),
                fg = Color(0xFF0E7490),
                onClick = onQuickOpenGraph
            )
            QuickShortcutPill(
                label = stringResource(R.string.shortcut_focus),
                icon = Icons.Rounded.Timer,
                bg = Color(0xFFD1FAE5),
                fg = Color(0xFF047857),
                onClick = onQuickOpenFocus
            )
        }

        Spacer(Modifier.height(10.dp))

        // Search Bar
        OutlinedTextField(
            value = filterState.searchQuery,
            onValueChange = onSearchChange,
            placeholder = {
                Text(
                    text = stringResource(R.string.search_notes_hint),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Rounded.Search,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            },
            trailingIcon = {
                if (filterState.searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchChange("") }) {
                        Icon(
                            imageVector = Icons.Rounded.Clear,
                            contentDescription = stringResource(R.string.search_clear_desc)
                        )
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("search_notes_input")
        )

        Spacer(Modifier.height(8.dp))

        // Subject + Quick Status Filters
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = filterState.onlyPinned,
                onClick = onTogglePinnedFilter,
                label = { Text(stringResource(R.string.filter_pinned)) },
                leadingIcon = {
                    Icon(
                        imageVector = if (filterState.onlyPinned) Icons.Rounded.PushPin else Icons.Outlined.PushPin,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                    selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimary
                )
            )
            FilterChip(
                selected = filterState.onlyWithFormulas,
                onClick = onToggleFormulaFilter,
                label = { Text(stringResource(R.string.filter_with_formulas)) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Rounded.Functions,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.secondary,
                    selectedLabelColor = MaterialTheme.colorScheme.onSecondary,
                    selectedLeadingIconColor = MaterialTheme.colorScheme.onSecondary
                )
            )
            FilterChip(
                selected = filterState.onlyNeedsReview,
                onClick = onToggleReviewFilter,
                label = { Text(stringResource(R.string.filter_needs_review)) },
                leadingIcon = {
                    Icon(
                        imageVector = if (filterState.onlyNeedsReview) Icons.Rounded.Bookmark else Icons.Outlined.BookmarkBorder,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.tertiary,
                    selectedLabelColor = MaterialTheme.colorScheme.onTertiary,
                    selectedLeadingIconColor = MaterialTheme.colorScheme.onTertiary
                )
            )
            subjects.forEach { subject ->
                FilterChip(
                    selected = filterState.selectedSubjectId == subject.id,
                    onClick = { onSelectSubject(subject.id) },
                    label = { Text(subject.displayName()) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = subject.accentStripeColor(),
                        selectedLabelColor = Color.White
                    )
                )
            }
            AssistChip(
                onClick = { showAddSubjectDialog = true },
                label = { Text(stringResource(R.string.subject_add_button)) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                }
            )
        }

        // User-created Tags Filter Strip
        if (tagsWithCount.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                tagsWithCount.forEach { item ->
                    TagPill(
                        tag = item.tag,
                        selected = item.tag.id in filterState.selectedTagIds,
                        count = item.noteCount,
                        onClick = { onToggleTag(item.tag.id) }
                    )
                }
            }
        }

        // Sort Selector & Active Filter Count Row (Feature 6)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box {
                Surface(
                    onClick = { showSortMenu = true },
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                    modifier = Modifier.testTag("sort_order_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.Sort,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = stringResource(R.string.sort_label, stringResource(sortOrder.labelRes)),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Icon(
                            imageVector = Icons.Rounded.ArrowDropDown,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                DropdownMenu(
                    expanded = showSortMenu,
                    onDismissRequest = { showSortMenu = false }
                ) {
                    NoteSortOrder.entries.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(stringResource(option.labelRes)) },
                            leadingIcon = {
                                if (option == sortOrder) {
                                    Icon(
                                        imageVector = Icons.Rounded.Check,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            },
                            onClick = {
                                showSortMenu = false
                                onChangeSortOrder(option)
                            }
                        )
                    }
                }
            }

            if (filterState.isAnyFilterActive) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.filter_found_count, filteredNotes.size),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(onClick = onClearFilters) {
                        Text(stringResource(R.string.filter_clear))
                    }
                }
            }
        }

        // Content Area: Strict 0-state when empty!
        when {
            allNotesCount == 0 -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyStateView(
                        title = stringResource(R.string.empty_notes_title),
                        subtitle = stringResource(R.string.empty_notes_subtitle),
                        showIllustration = true,
                        actionLabel = stringResource(R.string.action_new_note),
                        onAction = onCreateNote
                    )
                }
            }
            filteredNotes.isEmpty() -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyStateView(
                        title = stringResource(R.string.empty_filtered_title),
                        subtitle = stringResource(R.string.empty_filtered_subtitle),
                        showIllustration = false,
                        actionLabel = stringResource(R.string.filter_clear_all),
                        onAction = onClearFilters
                    )
                }
            }
            else -> {
                LazyVerticalStaggeredGrid(
                    columns = StaggeredGridCells.Fixed(if (isWideLayout) 2 else 1),
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
                    verticalItemSpacing = 12.dp,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredNotes, key = { it.note.id }) { item ->
                        NoteSummaryCard(
                            noteWithTags = item,
                            subject = subjects.resolveSubject(item.note.subject),
                            onClick = { onOpenNote(item.note.id) },
                            onTogglePin = { onTogglePinNote(item.note.id, item.note.isPinned) }
                        )
                    }
                }
            }
        }
    }

    if (showAddSubjectDialog) {
        CustomSubjectDialog(
            onDismiss = { showAddSubjectDialog = false },
            onConfirm = { name, colorHex ->
                onCreateSubject(name, colorHex)
                showAddSubjectDialog = false
            }
        )
    }
}

@Composable
private fun QuickShortcutPill(
    label: String,
    icon: ImageVector,
    bg: Color,
    fg: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = bg,
        border = BorderStroke(1.dp, fg.copy(alpha = 0.16f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = fg,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = fg
            )
        }
    }
}

@Composable
private fun HeroStatChip(text: String) {
    Surface(
        shape = RoundedCornerShape(50),
        color = Color.White.copy(alpha = 0.22f)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = Color.White,
            modifier = Modifier.padding(horizontal = 11.dp, vertical = 5.dp)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun NoteSummaryCard(
    noteWithTags: NoteWithTags,
    subject: SubjectEntity,
    onClick: () -> Unit,
    onTogglePin: () -> Unit
) {
    val note = noteWithTags.note
    val accent = subject.accentStripeColor()
    val badgeBg = subject.badgeBgColor()
    val badgeFg = subject.badgeFgColor()
    val dateLabel = SimpleDateFormat("d MMM HH:mm", Locale.forLanguageTag("th-TH")).format(Date(note.updatedAt))
    val previewContent = remember(note.content) {
        SimpleMarkdown.toReadablePlainLines(note.content)
            .filter { it.isNotBlank() }
            .joinToString("\n")
    }

    Surface(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("note_card_${note.id}"),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (note.isPinned) 1.5.dp else 1.dp,
            color = if (note.isPinned) accent.copy(alpha = 0.7f) else MaterialTheme.colorScheme.outlineVariant
        ),
        shadowElevation = if (note.isPinned) 3.dp else 1.dp
    ) {
        Row(modifier = Modifier.height(IntrinsicSize.Min)) {
            Box(
                modifier = Modifier
                    .width(6.dp)
                    .fillMaxHeight()
                    .background(accent)
            )
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FlowRow(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = badgeBg
                        ) {
                            Text(
                                text = subject.displayName(),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = badgeFg,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        if (note.needsReview) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.tertiaryContainer
                            ) {
                                Text(
                                    text = stringResource(R.string.badge_needs_review),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                                )
                            }
                        }
                        if (note.imagePaths.isNotEmpty()) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.secondaryContainer
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Image,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Text(
                                        text = note.imagePaths.size.toString(),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                }
                            }
                        }
                    }

                    IconButton(onClick = onTogglePin) {
                        Icon(
                            imageVector = if (note.isPinned) Icons.Rounded.PushPin else Icons.Outlined.PushPin,
                            contentDescription = stringResource(
                                if (note.isPinned) R.string.pin_action_unpin else R.string.pin_action_pin
                            ),
                            tint = if (note.isPinned) accent else MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))

                Text(
                    text = note.title.ifBlank { stringResource(R.string.note_untitled_paren) },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                if (previewContent.isNotBlank()) {
                    Spacer(Modifier.height(5.dp))
                    Text(
                        text = previewContent,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (note.formulas.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    val firstFormula = note.formulas.first()
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.16f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = firstFormula.expression.ifBlank { firstFormula.title },
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            if (note.formulas.size > 1) {
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = stringResource(R.string.note_extra_formulas, note.formulas.size - 1),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }

                if (noteWithTags.tags.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        noteWithTags.tags.forEach { tag ->
                            TagPill(tag = tag)
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))

                Text(
                    text = stringResource(R.string.note_updated_prefix, dateLabel),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f)
                )
            }
        }
    }
}
