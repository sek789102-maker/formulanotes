package com.CHANGE_ME.formulanotes.ui.theme

import androidx.annotation.StringRes
import androidx.compose.ui.graphics.Color
import com.CHANGE_ME.formulanotes.R

// Light Vibrant Blue-Sky-White Student Palette
val SkyWhiteBackground = Color(0xFFF4F8FF)
val PureSnowSurface = Color(0xFFFFFFFF)
val SoftAzureSurface = Color(0xFFEAF2FF)
val SkySurfaceHigh = Color(0xFFDCEBFF)

val RoyalBluePrimary = Color(0xFF1D4ED8)
val PureWhiteOnPrimary = Color(0xFFFFFFFF)
val AzurePrimaryContainer = Color(0xFFDBEAFE)
val OnAzurePrimaryContainer = Color(0xFF1E3A8A)

val SkyCyanSecondary = Color(0xFF0284C7)
val SkySecondaryContainer = Color(0xFFE0F2FE)
val OnSkySecondaryContainer = Color(0xFF075985)

val MintTealTertiary = Color(0xFF0D9488)
val MintTertiaryContainer = Color(0xFFCCFBF1)

val DeepNavyText = Color(0xFF0F172A)
val MutedSlateBlueText = Color(0xFF475569)
val SkyOutline = Color(0xFFBDD2F2)
val SoftSkyRuleLine = Color(0xFFDCE8FA)
val NotebookCoralMargin = Color(0xFFFB7185)
val VibrantCoralError = Color(0xFFDC2626)

// Gradient Hero Colors
val HeroBlueStart = Color(0xFF1D4ED8)
val HeroSkyEnd = Color(0xFF0EA5E9)

// Dark Midnight Navy & Glowing Sky Palette
val DarkMidnightBackground = Color(0xFF0B1220)
val DarkNavySurface = Color(0xFF131D31)
val DarkSlateBlueVariant = Color(0xFF1C2942)
val DarkNavyHigh = Color(0xFF253657)
val GlowingSkyPrimary = Color(0xFF60A5FA)
val DarkNavyOnPrimary = Color(0xFF082047)
val DarkBlueContainer = Color(0xFF1E3A8A)
val OnDarkBlueContainer = Color(0xFFDBEAFE)
val BrightCyanSecondary = Color(0xFF38BDF8)
val SnowCreamText = Color(0xFFF1F5F9)
val MutedIceBlueText = Color(0xFF94A3B8)
val DarkSkyOutline = Color(0xFF33476B)

// Vibrant Colorful Student Highlighter Tag Palette (8 shades)
data class TagTone(val container: Color, val content: Color, @param:StringRes val labelRes: Int)

val TagTones = listOf(
    TagTone(Color(0xFFDBEAFE), Color(0xFF1E40AF), R.string.tag_tone_sky_blue),
    TagTone(Color(0xFFE0F2FE), Color(0xFF0369A1), R.string.tag_tone_bright_cyan),
    TagTone(Color(0xFFEDE9FE), Color(0xFF5B21B6), R.string.tag_tone_lavender),
    TagTone(Color(0xFFD1FAE5), Color(0xFF065F46), R.string.tag_tone_mint),
    TagTone(Color(0xFFFEF3C7), Color(0xFF92400E), R.string.tag_tone_yellow),
    TagTone(Color(0xFFFFE4E6), Color(0xFF9F1239), R.string.tag_tone_coral),
    TagTone(Color(0xFFCFFAFE), Color(0xFF155E75), R.string.tag_tone_aqua),
    TagTone(Color(0xFFFCE7F3), Color(0xFF9D174D), R.string.tag_tone_pastel_pink)
)
