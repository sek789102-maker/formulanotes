package com.CHANGE_ME.formulanotes.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val SkyWhiteLightColorScheme = lightColorScheme(
    primary = RoyalBluePrimary,
    onPrimary = PureWhiteOnPrimary,
    primaryContainer = AzurePrimaryContainer,
    onPrimaryContainer = OnAzurePrimaryContainer,
    secondary = SkyCyanSecondary,
    onSecondary = PureWhiteOnPrimary,
    secondaryContainer = SkySecondaryContainer,
    onSecondaryContainer = OnSkySecondaryContainer,
    tertiary = MintTealTertiary,
    onTertiary = PureWhiteOnPrimary,
    tertiaryContainer = MintTertiaryContainer,
    onTertiaryContainer = DeepNavyText,
    background = SkyWhiteBackground,
    onBackground = DeepNavyText,
    surface = PureSnowSurface,
    onSurface = DeepNavyText,
    surfaceVariant = SoftAzureSurface,
    onSurfaceVariant = MutedSlateBlueText,
    surfaceContainerLowest = PureSnowSurface,
    surfaceContainerLow = SkyWhiteBackground,
    surfaceContainer = SoftAzureSurface,
    surfaceContainerHigh = SkySurfaceHigh,
    outline = SkyOutline,
    outlineVariant = SoftSkyRuleLine,
    error = VibrantCoralError
)

private val MidnightSkyDarkColorScheme = darkColorScheme(
    primary = GlowingSkyPrimary,
    onPrimary = DarkNavyOnPrimary,
    primaryContainer = DarkBlueContainer,
    onPrimaryContainer = OnDarkBlueContainer,
    secondary = BrightCyanSecondary,
    onSecondary = DarkNavyOnPrimary,
    secondaryContainer = DarkSlateBlueVariant,
    onSecondaryContainer = SnowCreamText,
    tertiary = MintTealTertiary,
    onTertiary = PureWhiteOnPrimary,
    tertiaryContainer = DarkSlateBlueVariant,
    onTertiaryContainer = SnowCreamText,
    background = DarkMidnightBackground,
    onBackground = SnowCreamText,
    surface = DarkNavySurface,
    onSurface = SnowCreamText,
    surfaceVariant = DarkSlateBlueVariant,
    onSurfaceVariant = MutedIceBlueText,
    surfaceContainerLowest = DarkMidnightBackground,
    surfaceContainerLow = DarkNavySurface,
    surfaceContainer = DarkSlateBlueVariant,
    surfaceContainerHigh = DarkNavyHigh,
    outline = DarkSkyOutline,
    outlineVariant = DarkSlateBlueVariant,
    error = VibrantCoralError
)

val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun SmutNoteTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) MidnightSkyDarkColorScheme else SkyWhiteLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
