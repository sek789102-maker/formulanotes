package com.CHANGE_ME.formulanotes.ui.viewmodel

import android.content.Context
import androidx.annotation.StringRes
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import com.CHANGE_ME.formulanotes.R
import com.CHANGE_ME.formulanotes.alarm.ExamNotificationScheduler
import com.CHANGE_ME.formulanotes.alarm.FocusAlarmScheduler
import com.CHANGE_ME.formulanotes.data.local.UserPreferences
import com.CHANGE_ME.formulanotes.data.local.UserPreferencesRepository
import com.CHANGE_ME.formulanotes.data.model.ExamCountdownEntity
import com.CHANGE_ME.formulanotes.data.model.FocusPreset
import com.CHANGE_ME.formulanotes.data.model.FormulaBlock
import com.CHANGE_ME.formulanotes.data.model.NoteSortOrder
import com.CHANGE_ME.formulanotes.data.model.NoteWithTags
import com.CHANGE_ME.formulanotes.data.model.StudySessionEntity
import com.CHANGE_ME.formulanotes.data.model.SubjectCategory
import com.CHANGE_ME.formulanotes.data.model.SubjectEntity
import com.CHANGE_ME.formulanotes.data.model.TagEntity
import com.CHANGE_ME.formulanotes.data.model.TagWithCount
import com.CHANGE_ME.formulanotes.data.model.resolveDisplayName
import com.CHANGE_ME.formulanotes.data.model.resolveSubject
import com.CHANGE_ME.formulanotes.data.repository.BackupImportSummary
import com.CHANGE_ME.formulanotes.data.repository.NotesRepository
import com.CHANGE_ME.formulanotes.domain.math.EvalResult
import com.CHANGE_ME.formulanotes.domain.math.MathEvaluator
import com.CHANGE_ME.formulanotes.domain.study.Sm2Rating
import com.CHANGE_ME.formulanotes.domain.study.StudyStatsCalculator
import com.CHANGE_ME.formulanotes.widget.ExamCountdownWidgetUpdater
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.Collator
import java.util.Locale
import java.util.concurrent.TimeUnit

data class StudyFormulaItem(
    val noteId: Long,
    val noteTitle: String,
    val subjectId: String,
    val tags: List<TagEntity>,
    val formula: FormulaBlock
)

data class CalcHistoryEntry(
    val id: Long,
    val expression: String,
    val result: String
)

enum class MathLabTool(@param:StringRes val labelRes: Int) {
    CALCULATOR(R.string.math_tool_calculator),
    GRAPH(R.string.math_tool_graph),
    CONVERTER(R.string.math_tool_converter)
}

data class FocusTimerState(
    val preset: FocusPreset = FocusPreset.FOCUS_25,
    val selectedSubjectId: String = SubjectCategory.MATH.name,
    val totalSeconds: Int = 25 * 60,
    val remainingSeconds: Int = 25 * 60,
    val endAtMillis: Long = 0L,
    val isRunning: Boolean = false,
    val completedEventCount: Int = 0
)

data class FilterState(
    val searchQuery: String = "",
    val selectedSubjectId: String? = null,
    val selectedTagIds: Set<Long> = emptySet(),
    val onlyPinned: Boolean = false,
    val onlyWithFormulas: Boolean = false,
    val onlyNeedsReview: Boolean = false
) {
    val isAnyFilterActive: Boolean
        get() = searchQuery.isNotBlank() ||
            selectedSubjectId != null ||
            selectedTagIds.isNotEmpty() ||
            onlyPinned ||
            onlyWithFormulas ||
            onlyNeedsReview
}

class NotesViewModel(
    private val appContext: Context,
    private val repository: NotesRepository,
    private val prefsRepository: UserPreferencesRepository,
    private val savedStateHandle: SavedStateHandle
) : ViewModel() {

    val userPreferences: StateFlow<UserPreferences> = prefsRepository.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserPreferences())

    val allNotes: StateFlow<List<NoteWithTags>> = repository.allNotesWithTags
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val trashedNotes: StateFlow<List<NoteWithTags>> = repository.trashedNotesWithTags
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tagsWithCount: StateFlow<List<TagWithCount>> = repository.allTagsWithCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTags: StateFlow<List<TagEntity>> = repository.allTags
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSubjects: StateFlow<List<SubjectEntity>> = repository.allSubjects
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            SubjectCategory.entries.map { it.toEntity() }
        )

    val allExams: StateFlow<List<ExamCountdownEntity>> = repository.allExams
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allStudySessions: StateFlow<List<StudySessionEntity>> = repository.allStudySessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _filterState = MutableStateFlow(FilterState())
    val filterState: StateFlow<FilterState> = _filterState.asStateFlow()

    private val thaiCollator: Collator = Collator.getInstance(Locale.forLanguageTag("th-TH")).apply {
        strength = Collator.PRIMARY
    }

    val filteredNotes: StateFlow<List<NoteWithTags>> = combine(
        allNotes,
        _filterState,
        userPreferences,
        allSubjects
    ) { notes, filter, prefs, subjects ->
        val filtered = notes.filter { item ->
            val n = item.note
            val matchesSubject = filter.selectedSubjectId == null || n.subject == filter.selectedSubjectId
            val matchesPinned = !filter.onlyPinned || n.isPinned
            val matchesFormulas = !filter.onlyWithFormulas || n.formulas.isNotEmpty()
            val matchesReview = !filter.onlyNeedsReview || n.needsReview
            val matchesTags = filter.selectedTagIds.isEmpty() ||
                filter.selectedTagIds.all { reqId -> item.tags.any { it.id == reqId } }
            val q = filter.searchQuery.trim()
            val matchesQuery = if (q.isEmpty()) {
                true
            } else {
                val subjectName = subjects.resolveSubject(n.subject).resolveDisplayName(appContext)
                n.title.contains(q, ignoreCase = true) ||
                    n.content.contains(q, ignoreCase = true) ||
                    subjectName.contains(q, ignoreCase = true) ||
                    item.tags.any { it.name.contains(q, ignoreCase = true) } ||
                    n.formulas.any {
                        it.title.contains(q, ignoreCase = true) ||
                            it.expression.contains(q, ignoreCase = true) ||
                            it.variablesNote.contains(q, ignoreCase = true)
                    }
            }
            matchesSubject && matchesPinned && matchesFormulas && matchesReview && matchesTags && matchesQuery
        }

        val comparator = Comparator<NoteWithTags> { a, b ->
            val pinCmp = b.note.isPinned.compareTo(a.note.isPinned)
            if (pinCmp != 0) return@Comparator pinCmp
            when (prefs.sortOrder) {
                NoteSortOrder.UPDATED_DESC -> b.note.updatedAt.compareTo(a.note.updatedAt)
                NoteSortOrder.CREATED_DESC -> b.note.createdAt.compareTo(a.note.createdAt)
                NoteSortOrder.TITLE_ASC -> {
                    val c = thaiCollator.compare(a.note.title, b.note.title)
                    if (c != 0) c else b.note.updatedAt.compareTo(a.note.updatedAt)
                }
                NoteSortOrder.SUBJECT_ASC -> {
                    val sA = subjects.resolveSubject(a.note.subject).resolveDisplayName(appContext)
                    val sB = subjects.resolveSubject(b.note.subject).resolveDisplayName(appContext)
                    val c = thaiCollator.compare(sA, sB)
                    if (c != 0) c else b.note.updatedAt.compareTo(a.note.updatedAt)
                }
            }
        }
        filtered.sortedWith(comparator)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val studyFormulas: StateFlow<List<StudyFormulaItem>> = allNotes
        .combine(MutableStateFlow(Unit)) { notes, _ ->
            notes.flatMap { noteWithTags ->
                noteWithTags.note.formulas
                    .filter { it.expression.isNotBlank() }
                    .map { formula ->
                        StudyFormulaItem(
                            noteId = noteWithTags.note.id,
                            noteTitle = noteWithTags.note.title,
                            subjectId = noteWithTags.note.subject,
                            tags = noteWithTags.tags,
                            formula = formula
                        )
                    }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val shouldShowBackupReminder: StateFlow<Boolean> = combine(allNotes, userPreferences) { notes, prefs ->
        val oldestCreated = notes.minOfOrNull { it.note.createdAt }
        StudyStatsCalculator.shouldShowBackupReminder(
            notesCount = notes.size,
            oldestNoteCreatedAtMillis = oldestCreated,
            lastBackupExportedAtMillis = prefs.lastBackupExportedAtMillis,
            dismissedUntilMillis = prefs.backupReminderDismissedUntilMillis
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    // Undo Delete (moves to Trash; Undo restores immediately)
    private var pendingUndoNoteId: Long? = null
    private val _undoSnackbarTrigger = Channel<Unit>(Channel.BUFFERED)
    val undoSnackbarTrigger: Flow<Unit> = _undoSnackbarTrigger.receiveAsFlow()

    // Pomodoro Focus Timer State (Timestamp-based)
    private val _focusTimerState = MutableStateFlow(FocusTimerState())
    val focusTimerState: StateFlow<FocusTimerState> = _focusTimerState.asStateFlow()
    private var timerJob: Job? = null

    // Calculator & Math Lab State (persisted via SavedStateHandle)
    private val _activeMathTool = MutableStateFlow(
        MathLabTool.entries.firstOrNull { it.name == savedStateHandle.get<String>(KEY_MATH_TOOL) }
            ?: MathLabTool.CALCULATOR
    )
    val activeMathTool: StateFlow<MathLabTool> = _activeMathTool.asStateFlow()

    private val _graphExpression = MutableStateFlow(savedStateHandle.get<String>(KEY_GRAPH_EXPR).orEmpty())
    val graphExpression: StateFlow<String> = _graphExpression.asStateFlow()

    private val _calcExpression = MutableStateFlow(savedStateHandle.get<String>(KEY_CALC_EXPR).orEmpty())
    val calcExpression: StateFlow<String> = _calcExpression.asStateFlow()

    private val _calcUseDegrees = MutableStateFlow(savedStateHandle.get<Boolean>(KEY_CALC_DEGREES) ?: true)
    val calcUseDegrees: StateFlow<Boolean> = _calcUseDegrees.asStateFlow()

    private val _calcHistory = MutableStateFlow<List<CalcHistoryEntry>>(emptyList())
    val calcHistory: StateFlow<List<CalcHistoryEntry>> = _calcHistory.asStateFlow()

    private val _calcError = MutableStateFlow<String?>(null)
    val calcError: StateFlow<String?> = _calcError.asStateFlow()

    private val _lastAnswer = MutableStateFlow(savedStateHandle.get<String>(KEY_LAST_ANSWER))
    val lastAnswer: StateFlow<String?> = _lastAnswer.asStateFlow()

    init {
        restoreFocusTimerFromPrefs()
    }

    private fun restoreFocusTimerFromPrefs() {
        viewModelScope.launch {
            val persisted = prefsRepository.focusTimerFlow.first()
            val totalSecs = persisted.preset.minutes * 60
            if (persisted.endAtMillis > 0L) {
                val now = System.currentTimeMillis()
                if (now >= persisted.endAtMillis) {
                    val claimed = prefsRepository.consumeFocusTimerCompletion(persisted.endAtMillis)
                    if (claimed && persisted.preset.isStudy) {
                        repository.recordStudySession(persisted.subjectId, persisted.preset.minutes)
                    }
                    _focusTimerState.value = FocusTimerState(
                        preset = persisted.preset,
                        selectedSubjectId = persisted.subjectId,
                        totalSeconds = totalSecs,
                        remainingSeconds = totalSecs,
                        endAtMillis = 0L,
                        isRunning = false,
                        completedEventCount = if (claimed) 1 else 0
                    )
                } else {
                    val remaining = computeRemainingSeconds(persisted.endAtMillis, now)
                    _focusTimerState.value = FocusTimerState(
                        preset = persisted.preset,
                        selectedSubjectId = persisted.subjectId,
                        totalSeconds = totalSecs,
                        remainingSeconds = remaining,
                        endAtMillis = persisted.endAtMillis,
                        isRunning = true
                    )
                    startTimestampTicker()
                }
            } else {
                val remaining = if (persisted.pausedRemainingSeconds in 0..totalSecs) {
                    persisted.pausedRemainingSeconds
                } else {
                    totalSecs
                }
                _focusTimerState.value = FocusTimerState(
                    preset = persisted.preset,
                    selectedSubjectId = persisted.subjectId,
                    totalSeconds = totalSecs,
                    remainingSeconds = remaining,
                    endAtMillis = 0L,
                    isRunning = false
                )
            }
        }
    }

    fun refreshFocusTimerFromClock() {
        val current = _focusTimerState.value
        if (!current.isRunning || current.endAtMillis <= 0L) {
            restoreFocusTimerFromPrefs()
            return
        }
        val now = System.currentTimeMillis()
        if (now >= current.endAtMillis) {
            viewModelScope.launch {
                completeRunningTimer(current.endAtMillis, current.preset, current.selectedSubjectId)
            }
        } else {
            val rem = computeRemainingSeconds(current.endAtMillis, now)
            _focusTimerState.update { it.copy(remainingSeconds = rem) }
        }
    }

    fun observeNoteById(noteId: Long): Flow<NoteWithTags?> = repository.observeNoteById(noteId)

    fun updateSearchQuery(query: String) {
        _filterState.update { it.copy(searchQuery = query) }
    }

    fun selectSubjectFilter(subjectId: String?) {
        _filterState.update {
            it.copy(selectedSubjectId = if (it.selectedSubjectId == subjectId) null else subjectId)
        }
    }

    fun toggleTagFilter(tagId: Long) {
        _filterState.update { current ->
            val next = if (tagId in current.selectedTagIds) {
                current.selectedTagIds - tagId
            } else {
                current.selectedTagIds + tagId
            }
            current.copy(selectedTagIds = next)
        }
    }

    fun setSingleTagFilter(tagId: Long) {
        _filterState.update { FilterState(selectedTagIds = setOf(tagId)) }
    }

    fun toggleOnlyPinned() {
        _filterState.update { it.copy(onlyPinned = !it.onlyPinned) }
    }

    fun toggleOnlyWithFormulas() {
        _filterState.update { it.copy(onlyWithFormulas = !it.onlyWithFormulas) }
    }

    fun toggleOnlyNeedsReview() {
        _filterState.update { it.copy(onlyNeedsReview = !it.onlyNeedsReview) }
    }

    fun clearAllFilters() {
        _filterState.value = FilterState()
    }

    fun setSortOrder(order: NoteSortOrder) {
        viewModelScope.launch {
            prefsRepository.setSortOrder(order)
        }
    }

    suspend fun saveNoteSuspend(
        existingId: Long,
        title: String,
        subjectId: String,
        content: String,
        formulas: List<FormulaBlock>,
        imagePaths: List<String>,
        tagIds: List<Long>,
        isPinned: Boolean,
        needsReview: Boolean,
        paperStyle: Int,
        createdAt: Long? = null
    ): Long {
        return repository.saveNote(
            existingId = existingId,
            title = title,
            subjectId = subjectId,
            content = content,
            formulas = formulas,
            imagePaths = imagePaths,
            tagIds = tagIds,
            isPinned = isPinned,
            needsReview = needsReview,
            paperStyle = paperStyle,
            createdAt = createdAt
        )
    }

    fun saveNote(
        existingId: Long,
        title: String,
        subjectId: String,
        content: String,
        formulas: List<FormulaBlock>,
        imagePaths: List<String>,
        tagIds: List<Long>,
        isPinned: Boolean,
        needsReview: Boolean,
        paperStyle: Int,
        createdAt: Long? = null,
        onSaved: (Long) -> Unit = {}
    ) {
        viewModelScope.launch {
            val savedId = saveNoteSuspend(
                existingId = existingId,
                title = title,
                subjectId = subjectId,
                content = content,
                formulas = formulas,
                imagePaths = imagePaths,
                tagIds = tagIds,
                isPinned = isPinned,
                needsReview = needsReview,
                paperStyle = paperStyle,
                createdAt = createdAt
            )
            onSaved(savedId)
        }
    }

    fun deleteNote(noteId: Long, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            pendingUndoNoteId = noteId
            repository.softDeleteNote(noteId)
            onDeleted()
            _undoSnackbarTrigger.trySend(Unit)
        }
    }

    fun undoDeleteNote() {
        val noteId = pendingUndoNoteId ?: return
        pendingUndoNoteId = null
        viewModelScope.launch {
            repository.restoreNoteFromTrash(noteId)
        }
    }

    fun restoreFromTrash(noteId: Long) {
        viewModelScope.launch {
            repository.restoreNoteFromTrash(noteId)
        }
    }

    fun permanentlyDeleteNote(noteId: Long) {
        viewModelScope.launch {
            repository.permanentlyDeleteNote(noteId)
        }
    }

    fun emptyTrash() {
        viewModelScope.launch {
            repository.emptyTrash()
        }
    }

    fun togglePin(noteId: Long, currentlyPinned: Boolean) {
        viewModelScope.launch {
            repository.togglePin(noteId, !currentlyPinned)
        }
    }

    fun toggleNeedsReview(noteId: Long, currentlyNeedsReview: Boolean) {
        viewModelScope.launch {
            repository.toggleNeedsReview(noteId, !currentlyNeedsReview)
        }
    }

    fun toggleChecklistLine(noteId: Long, lineIndex: Int) {
        viewModelScope.launch {
            repository.toggleChecklistLine(noteId, lineIndex)
        }
    }

    fun rateFormulaSm2(noteId: Long, formulaId: String, rating: Sm2Rating) {
        viewModelScope.launch {
            repository.rateFormulaSm2(noteId, formulaId, rating)
        }
    }

    fun toggleFormulaMastered(noteId: Long, formulaId: String) {
        viewModelScope.launch {
            repository.toggleFormulaMastered(noteId, formulaId)
        }
    }

    fun createTag(name: String, colorIndex: Int, onCreated: (Long) -> Unit = {}) {
        val clean = name.trim().removePrefix("#").trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            val id = repository.createOrGetTag(clean, colorIndex)
            onCreated(id)
        }
    }

    fun updateTag(tag: TagEntity) {
        viewModelScope.launch {
            repository.updateTag(tag)
        }
    }

    fun deleteTag(tagId: Long) {
        viewModelScope.launch {
            repository.deleteTag(tagId)
            _filterState.update { it.copy(selectedTagIds = it.selectedTagIds - tagId) }
        }
    }

    fun createCustomSubject(name: String, colorHex: Long, onCreated: (SubjectEntity) -> Unit = {}) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            val created = repository.createCustomSubject(clean, colorHex)
            onCreated(created)
        }
    }

    fun updateCustomSubject(subject: SubjectEntity) {
        viewModelScope.launch {
            repository.updateCustomSubject(subject)
            ExamCountdownWidgetUpdater.updateAll(appContext)
        }
    }

    fun deleteCustomSubject(subjectId: String) {
        viewModelScope.launch {
            repository.deleteCustomSubject(subjectId)
            _filterState.update { state ->
                if (state.selectedSubjectId == subjectId) state.copy(selectedSubjectId = null) else state
            }
            if (_focusTimerState.value.selectedSubjectId == subjectId) {
                selectFocusSubject(SubjectCategory.GENERAL.name)
            }
            ExamCountdownWidgetUpdater.updateAll(appContext)
        }
    }

    fun addExamCountdown(title: String, subjectId: String, examDateMillis: Long, note: String) {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.addExam(title, subjectId, examDateMillis, note)
            val exams = repository.getAllExamsSnapshot()
            ExamNotificationScheduler.rescheduleAll(
                context = appContext,
                exams = exams,
                enabled = userPreferences.value.examNotificationsEnabled
            )
            ExamCountdownWidgetUpdater.updateAll(appContext)
        }
    }

    fun deleteExamCountdown(examId: Long) {
        viewModelScope.launch {
            ExamNotificationScheduler.cancelForExam(appContext, examId)
            repository.deleteExam(examId)
            ExamCountdownWidgetUpdater.updateAll(appContext)
        }
    }

    fun setExamNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepository.setExamNotificationsEnabled(enabled)
            val exams = repository.getAllExamsSnapshot()
            ExamNotificationScheduler.rescheduleAll(
                context = appContext,
                exams = exams,
                enabled = enabled
            )
        }
    }

    fun markBackupExported() {
        viewModelScope.launch {
            prefsRepository.setLastBackupExportedAt(System.currentTimeMillis())
        }
    }

    fun dismissBackupReminderForLater() {
        viewModelScope.launch {
            val threeDaysLater = System.currentTimeMillis() + TimeUnit.DAYS.toMillis(3)
            prefsRepository.dismissBackupReminderUntil(threeDaysLater)
        }
    }

    fun selectFocusPreset(preset: FocusPreset) {
        timerJob?.cancel()
        FocusAlarmScheduler.cancel(appContext)
        val secs = preset.minutes * 60
        val currentSubject = _focusTimerState.value.selectedSubjectId
        _focusTimerState.update {
            it.copy(
                preset = preset,
                totalSeconds = secs,
                remainingSeconds = secs,
                endAtMillis = 0L,
                isRunning = false
            )
        }
        viewModelScope.launch {
            prefsRepository.saveResetTimer(preset, currentSubject)
        }
    }

    fun selectFocusSubject(subjectId: String) {
        val current = _focusTimerState.value
        _focusTimerState.update { it.copy(selectedSubjectId = subjectId) }
        viewModelScope.launch {
            if (current.isRunning && current.endAtMillis > 0L) {
                prefsRepository.saveRunningTimer(current.preset, subjectId, current.endAtMillis)
                FocusAlarmScheduler.schedule(appContext, current.endAtMillis, current.preset, subjectId)
            } else {
                prefsRepository.savePausedTimer(current.preset, subjectId, current.remainingSeconds)
            }
        }
    }

    fun toggleFocusTimer() {
        val current = _focusTimerState.value
        if (current.isRunning) {
            timerJob?.cancel()
            FocusAlarmScheduler.cancel(appContext)
            val remaining = if (current.endAtMillis > 0L) {
                computeRemainingSeconds(current.endAtMillis, System.currentTimeMillis())
            } else {
                current.remainingSeconds
            }
            _focusTimerState.update {
                it.copy(
                    isRunning = false,
                    endAtMillis = 0L,
                    remainingSeconds = remaining
                )
            }
            viewModelScope.launch {
                prefsRepository.savePausedTimer(current.preset, current.selectedSubjectId, remaining)
            }
        } else {
            val remaining = current.remainingSeconds.coerceAtLeast(1)
            val endAtMillis = System.currentTimeMillis() + remaining * 1000L
            _focusTimerState.update {
                it.copy(
                    isRunning = true,
                    endAtMillis = endAtMillis,
                    remainingSeconds = remaining
                )
            }
            FocusAlarmScheduler.schedule(appContext, endAtMillis, current.preset, current.selectedSubjectId)
            viewModelScope.launch {
                prefsRepository.saveRunningTimer(current.preset, current.selectedSubjectId, endAtMillis)
            }
            startTimestampTicker()
        }
    }

    private fun startTimestampTicker() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                val state = _focusTimerState.value
                if (!state.isRunning || state.endAtMillis <= 0L) break

                val now = System.currentTimeMillis()
                if (now >= state.endAtMillis) {
                    completeRunningTimer(state.endAtMillis, state.preset, state.selectedSubjectId)
                    break
                } else {
                    val remaining = computeRemainingSeconds(state.endAtMillis, now)
                    if (remaining != state.remainingSeconds) {
                        _focusTimerState.update { it.copy(remainingSeconds = remaining) }
                    }
                }
                delay(250L)
            }
        }
    }

    private suspend fun completeRunningTimer(
        endAtMillis: Long,
        preset: FocusPreset,
        subjectId: String
    ) {
        val claimed = prefsRepository.consumeFocusTimerCompletion(endAtMillis)
        FocusAlarmScheduler.cancel(appContext)
        if (claimed && preset.isStudy) {
            repository.recordStudySession(subjectId, preset.minutes)
        }
        _focusTimerState.update {
            it.copy(
                remainingSeconds = it.totalSeconds,
                endAtMillis = 0L,
                isRunning = false,
                completedEventCount = if (claimed) it.completedEventCount + 1 else it.completedEventCount
            )
        }
    }

    fun resetFocusTimer() {
        timerJob?.cancel()
        FocusAlarmScheduler.cancel(appContext)
        val current = _focusTimerState.value
        _focusTimerState.update {
            it.copy(
                remainingSeconds = it.totalSeconds,
                endAtMillis = 0L,
                isRunning = false
            )
        }
        viewModelScope.launch {
            prefsRepository.saveResetTimer(current.preset, current.selectedSubjectId)
        }
    }

    fun setDarkMode(enabled: Boolean) {
        viewModelScope.launch { prefsRepository.setDarkMode(enabled) }
    }

    fun setDefaultPaperStyle(style: Int) {
        viewModelScope.launch { prefsRepository.setDefaultPaperStyle(style) }
    }

    suspend fun exportBackupJson(): String = repository.exportBackupJson()

    suspend fun importBackupJson(json: String): Result<BackupImportSummary> {
        val result = repository.importBackupJson(json)
        if (result.isSuccess) {
            val exams = repository.getAllExamsSnapshot()
            ExamNotificationScheduler.rescheduleAll(
                context = appContext,
                exams = exams,
                enabled = userPreferences.value.examNotificationsEnabled
            )
            ExamCountdownWidgetUpdater.updateAll(appContext)
        }
        return result
    }

    // Math Lab & Calculator methods
    fun setActiveMathTool(tool: MathLabTool) {
        _activeMathTool.value = tool
        savedStateHandle[KEY_MATH_TOOL] = tool.name
    }

    fun setGraphExpression(expr: String) {
        _graphExpression.value = expr
        savedStateHandle[KEY_GRAPH_EXPR] = expr
    }

    fun openFormulaInGraph(rawFormula: String) {
        val parsed = MathEvaluator.inspectFormula(rawFormula)
        setGraphExpression(parsed.evaluableExpression)
        setActiveMathTool(MathLabTool.GRAPH)
    }

    fun setCalcExpression(expr: String) {
        _calcExpression.value = expr
        savedStateHandle[KEY_CALC_EXPR] = expr
        _calcError.value = null
    }

    fun appendCalcToken(token: String) {
        val next = _calcExpression.value + token
        _calcExpression.value = next
        savedStateHandle[KEY_CALC_EXPR] = next
        _calcError.value = null
    }

    fun backspaceCalc() {
        val cur = _calcExpression.value
        val next = if (cur.isNotEmpty()) cur.dropLast(1) else ""
        _calcExpression.value = next
        savedStateHandle[KEY_CALC_EXPR] = next
        _calcError.value = null
    }

    fun clearCalc() {
        _calcExpression.value = ""
        savedStateHandle[KEY_CALC_EXPR] = ""
        _calcError.value = null
    }

    fun toggleCalcDegrees() {
        val next = !_calcUseDegrees.value
        _calcUseDegrees.value = next
        savedStateHandle[KEY_CALC_DEGREES] = next
    }

    fun evaluateCalculator() {
        val expr = _calcExpression.value.trim()
        if (expr.isEmpty()) return
        when (val res = MathEvaluator.evaluate(expr, useDegrees = _calcUseDegrees.value)) {
            is EvalResult.Success -> {
                _lastAnswer.value = res.formatted
                savedStateHandle[KEY_LAST_ANSWER] = res.formatted
                _calcError.value = null
                _calcHistory.update { old ->
                    (listOf(CalcHistoryEntry(System.nanoTime(), expr, res.formatted)) + old).take(30)
                }
                _calcExpression.value = res.formatted
                savedStateHandle[KEY_CALC_EXPR] = res.formatted
            }
            is EvalResult.Error -> {
                _calcError.value = res.localizedMessage(appContext)
            }
        }
    }

    fun clearCalcHistory() {
        _calcHistory.value = emptyList()
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }

    class Factory(
        private val appContext: Context,
        private val repository: NotesRepository,
        private val prefsRepository: UserPreferencesRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T {
            val savedStateHandle = extras.createSavedStateHandle()
            return NotesViewModel(appContext, repository, prefsRepository, savedStateHandle) as T
        }
    }

    companion object {
        private const val KEY_MATH_TOOL = "math_tool"
        private const val KEY_GRAPH_EXPR = "graph_expr"
        private const val KEY_CALC_EXPR = "calc_expr"
        private const val KEY_CALC_DEGREES = "calc_degrees"
        private const val KEY_LAST_ANSWER = "last_answer"

        fun computeRemainingSeconds(endAtMillis: Long, nowMillis: Long): Int {
            val diff = endAtMillis - nowMillis
            if (diff <= 0L) return 0
            return ((diff + 999L) / 1000L).toInt()
        }
    }
}
