package com.CHANGE_ME.formulanotes

import com.CHANGE_ME.formulanotes.data.model.FormulaBlock
import com.CHANGE_ME.formulanotes.data.model.StudySessionEntity
import com.CHANGE_ME.formulanotes.domain.markdown.MarkdownBlock
import com.CHANGE_ME.formulanotes.domain.markdown.SimpleMarkdown
import com.CHANGE_ME.formulanotes.domain.study.Sm2Rating
import com.CHANGE_ME.formulanotes.domain.study.Sm2Scheduler
import com.CHANGE_ME.formulanotes.domain.study.StudyStatsCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.TimeZone
import java.util.concurrent.TimeUnit

class DomainLogicUnitTest {

    @Test
    fun `sm2 scheduler increases intervals on good and easy and resets on hard`() {
        val base = FormulaBlock(id = "f1", title = "F = ma", expression = "F = m * a")
        val day0 = 1_700_000_000_000L

        // First GOOD -> 1 day, repetitions = 1
        val afterFirstGood = Sm2Scheduler.scheduleReview(base, Sm2Rating.GOOD, day0)
        assertEquals(1, afterFirstGood.repetitions)
        assertEquals(1, afterFirstGood.intervalDays)
        assertTrue(afterFirstGood.mastered)

        // Second GOOD -> 6 days, repetitions = 2
        val afterSecondGood = Sm2Scheduler.scheduleReview(afterFirstGood, Sm2Rating.GOOD, day0 + TimeUnit.DAYS.toMillis(1))
        assertEquals(2, afterSecondGood.repetitions)
        assertEquals(6, afterSecondGood.intervalDays)

        // EASY -> longer interval & higher EF
        val afterEasy = Sm2Scheduler.scheduleReview(afterSecondGood, Sm2Rating.EASY, day0 + TimeUnit.DAYS.toMillis(7))
        assertTrue(afterEasy.intervalDays > 6)
        assertTrue(afterEasy.easeFactor > 2.5)

        // HARD -> resets repetitions to 0 and interval back to 1
        val afterHard = Sm2Scheduler.scheduleReview(afterEasy, Sm2Rating.HARD, day0 + TimeUnit.DAYS.toMillis(20))
        assertEquals(0, afterHard.repetitions)
        assertEquals(1, afterHard.intervalDays)
        assertFalse(afterHard.mastered)
    }

    @Test
    fun `sm2 due check recognizes unreviewed, due, and future cards`() {
        val now = 1_700_000_000_000L
        val endToday = Sm2Scheduler.endOfDayMillis(now)

        val fresh = FormulaBlock(title = "New", expression = "a + b")
        assertTrue(Sm2Scheduler.isDueForReview(fresh, endToday))

        val scheduledToday = Sm2Scheduler.scheduleReview(fresh, Sm2Rating.GOOD, now)
        assertFalse(Sm2Scheduler.isDueForReview(scheduledToday, endToday))

        val endTomorrow = Sm2Scheduler.endOfDayMillis(now + TimeUnit.DAYS.toMillis(1))
        assertTrue(Sm2Scheduler.isDueForReview(scheduledToday, endTomorrow))
    }

    @Test
    fun `study stats calculator computes consecutive streak and breaks on missed day`() {
        val utc = TimeZone.getTimeZone("UTC")
        val dayMs = TimeUnit.DAYS.toMillis(1)
        val todayNoon = 1_700_050_000_000L // fixed reference UTC timestamp

        val consecutiveSessions = listOf(
            StudySessionEntity(subject = "MATH", durationMinutes = 25, completedAt = todayNoon),
            StudySessionEntity(subject = "PHYSICS", durationMinutes = 15, completedAt = todayNoon - dayMs),
            StudySessionEntity(subject = "MATH", durationMinutes = 20, completedAt = todayNoon - 2 * dayMs)
        )
        assertEquals(3, StudyStatsCalculator.computeReadingStreak(consecutiveSessions, todayNoon, utc))

        // Gap yesterday, studied 2 days ago -> streak breaks to 0 (if today also empty) or 1 (if today studied)
        val brokenSessions = listOf(
            StudySessionEntity(subject = "MATH", durationMinutes = 25, completedAt = todayNoon),
            StudySessionEntity(subject = "MATH", durationMinutes = 25, completedAt = todayNoon - 2 * dayMs)
        )
        assertEquals(1, StudyStatsCalculator.computeReadingStreak(brokenSessions, todayNoon, utc))

        val bars = StudyStatsCalculator.computeLast7DaysStats(consecutiveSessions, todayNoon, utc)
        assertEquals(7, bars.size)
        assertEquals(25, bars.last().totalMinutes)
    }

    @Test
    fun `backup reminder triggers after 14 days unless recently exported or snoozed`() {
        val now = 1_700_000_000_000L
        val fifteenDaysAgo = now - TimeUnit.DAYS.toMillis(15)
        val fiveDaysAgo = now - TimeUnit.DAYS.toMillis(5)
        val futureSnooze = now + TimeUnit.DAYS.toMillis(2)

        assertTrue(StudyStatsCalculator.shouldShowBackupReminder(1, fifteenDaysAgo, 0L, 0L, now))
        assertFalse(StudyStatsCalculator.shouldShowBackupReminder(0, fifteenDaysAgo, 0L, 0L, now))
        assertFalse(StudyStatsCalculator.shouldShowBackupReminder(3, fifteenDaysAgo, fiveDaysAgo, 0L, now))
        assertFalse(StudyStatsCalculator.shouldShowBackupReminder(3, fifteenDaysAgo, 0L, futureSnooze, now))
    }

    @Test
    fun `simple markdown parses blocks and toggles checklist lines accurately`() {
        val raw = "# หัวข้อใหญ่\n- ข้อแรก\n[ ] ทบทวน ==สูตรสำคัญ== **ด่วน**\n[x] เสร็จแล้ว"
        val blocks = SimpleMarkdown.parseBlocks(raw)
        assertEquals(4, blocks.size)
        assertTrue(blocks[0] is MarkdownBlock.Heading)
        assertTrue(blocks[1] is MarkdownBlock.Bullet)
        assertTrue(blocks[2] is MarkdownBlock.Checklist)
        assertFalse((blocks[2] as MarkdownBlock.Checklist).checked)
        assertTrue((blocks[3] as MarkdownBlock.Checklist).checked)

        val toggled = SimpleMarkdown.toggleChecklistLine(raw, 2)
        val updatedBlocks = SimpleMarkdown.parseBlocks(toggled)
        assertTrue((updatedBlocks[2] as MarkdownBlock.Checklist).checked)
    }
}
