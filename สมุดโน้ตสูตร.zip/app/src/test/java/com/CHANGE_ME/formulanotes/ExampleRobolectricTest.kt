package com.CHANGE_ME.formulanotes

import android.content.Context
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.CHANGE_ME.formulanotes.data.local.AppDatabase
import com.CHANGE_ME.formulanotes.data.model.FormulaBlock
import com.CHANGE_ME.formulanotes.data.model.SubjectCategory
import com.CHANGE_ME.formulanotes.data.repository.NotesRepository
import com.CHANGE_ME.formulanotes.domain.study.Sm2Rating
import com.CHANGE_ME.formulanotes.ui.viewmodel.NotesViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.TimeUnit

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private fun appContext(): Context = ApplicationProvider.getApplicationContext()

    private fun buildInMemoryDb(): AppDatabase {
        return Room.inMemoryDatabaseBuilder(appContext(), AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @Test
    fun `app name matches localized title`() {
        val appName = appContext().getString(R.string.app_name)
        assertEquals("สมุดโน้ตสูตร", appName)
    }

    @Test
    fun `fresh database starts completely empty across notes, tags, exams, and focus sessions`() = runBlocking {
        val db = buildInMemoryDb()
        try {
            val repo = NotesRepository(appContext(), db)
            assertTrue(repo.allNotesWithTags.first().isEmpty())
            assertTrue(repo.trashedNotesWithTags.first().isEmpty())
            assertTrue(repo.allTags.first().isEmpty())
            assertTrue(repo.allExams.first().isEmpty())
            assertTrue(repo.allStudySessions.first().isEmpty())

            val tagId = repo.createOrGetTag("สอบกลางภาค", 1)
            val noteId = repo.saveNote(
                existingId = 0L,
                title = "พลังงานจลน์",
                subjectId = SubjectCategory.PHYSICS.name,
                content = "ทบทวนบทที่ 4",
                formulas = listOf(FormulaBlock(title = "Ek", expression = "E = 0.5 × m × v²")),
                imagePaths = emptyList(),
                tagIds = listOf(tagId),
                isPinned = true,
                needsReview = false,
                paperStyle = 0
            )
            repo.addExam("สอบกลางภาคฟิสิกส์", SubjectCategory.PHYSICS.name, System.currentTimeMillis() + 86400000L, "บทที่ 1-4")
            repo.recordStudySession(SubjectCategory.PHYSICS.name, 25)

            val savedNotes = repo.allNotesWithTags.first()
            assertEquals(1, savedNotes.size)
            assertEquals(noteId, savedNotes.first().note.id)
            assertEquals(1, savedNotes.first().tags.size)
            assertEquals("สอบกลางภาค", savedNotes.first().tags.first().name)
            assertEquals(1, repo.allExams.first().size)
            assertEquals(25, repo.allStudySessions.first().first().durationMinutes)
        } finally {
            db.close()
        }
    }

    @Test
    fun `backup export v3 includes custom subjects, exams, sessions, SM-2 data and skips duplicates on re-import`() = runBlocking {
        val sourceDb = buildInMemoryDb()
        val targetDb = buildInMemoryDb()
        try {
            val sourceRepo = NotesRepository(appContext(), sourceDb)
            val customSubject = sourceRepo.createCustomSubject("ดาราศาสตร์", 0xFF0284C7)
            val tagId = sourceRepo.createOrGetTag("ปลายภาค", 2)
            val noteId = sourceRepo.saveNote(
                existingId = 0L,
                title = "กฎของเคปเลอร์",
                subjectId = customSubject.id,
                content = "- [ ] ท่องสมการ\n**สำคัญมาก**",
                formulas = listOf(FormulaBlock(id = "f1", title = "คาบโคจร", expression = "T² = a³")),
                imagePaths = emptyList(),
                tagIds = listOf(tagId),
                isPinned = false,
                needsReview = true,
                paperStyle = 1,
                createdAt = 1700000000000L,
                updatedAt = 1700000000000L
            )
            sourceRepo.rateFormulaSm2(noteId, "f1", Sm2Rating.EASY)
            sourceRepo.addExam("สอบดาราศาสตร์", customSubject.id, 1750000000000L, "บทวงโคจร")
            sourceRepo.recordStudySession(customSubject.id, 25)

            val backupJson = sourceRepo.exportBackupJson()
            val root = JSONObject(backupJson)
            assertEquals(NotesRepository.BACKUP_VERSION, root.getInt("version"))
            assertTrue(root.getJSONArray("subjects").length() >= 1)
            assertEquals(1, root.getJSONArray("exam_countdowns").length())
            assertEquals(1, root.getJSONArray("study_sessions").length())

            val targetRepo = NotesRepository(appContext(), targetDb)
            val firstImport = targetRepo.importBackupJson(backupJson).getOrThrow()
            assertEquals(1, firstImport.importedNotes)
            assertEquals(0, firstImport.skippedNotes)
            assertEquals(1, firstImport.importedExams)
            assertEquals(1, firstImport.importedSessions)
            assertTrue(firstImport.importedSubjects >= 1)

            val importedNote = targetRepo.allNotesWithTags.first().first().note
            assertEquals(customSubject.id, importedNote.subject)
            assertEquals(4, importedNote.formulas.first().intervalDays)

            val secondImport = targetRepo.importBackupJson(backupJson).getOrThrow()
            assertEquals(0, secondImport.importedNotes)
            assertEquals(1, secondImport.skippedNotes)
            assertEquals(0, secondImport.importedExams)
            assertEquals(1, secondImport.skippedExams)
            assertEquals(0, secondImport.importedSessions)
            assertEquals(1, secondImport.skippedSessions)
        } finally {
            sourceDb.close()
            targetDb.close()
        }
    }

    @Test
    fun `legacy v1 backup without version or exams imports cleanly and mid-import error rolls back`() = runBlocking {
        val db = buildInMemoryDb()
        try {
            val repo = NotesRepository(appContext(), db)

            val legacyV1Json = """
                {
                  "notes": [
                    {
                      "title": "สมการกำลังสอง",
                      "subject": "MATH",
                      "content": "สูตรหลัก",
                      "createdAt": 1690000000000,
                      "formulas": [
                        { "title": "Quadratic", "expression": "x = (-b ± √(b² - 4ac)) / (2a)" }
                      ],
                      "tags": [
                        { "name": "พีชคณิต", "colorIndex": 0 }
                      ]
                    }
                  ]
                }
            """.trimIndent()

            val v1Result = repo.importBackupJson(legacyV1Json).getOrThrow()
            assertEquals(1, v1Result.importedNotes)
            assertEquals(0, v1Result.importedExams)
            assertEquals(0, v1Result.importedSessions)

            val brokenMidImportJson = """
                {
                  "version": 2,
                  "notes": [
                    {
                      "title": "โน้ตที่ไม่ควรถูกบันทึก",
                      "subject": "CHEMISTRY",
                      "content": "จะถูก rollback",
                      "createdAt": 1710000000000
                    },
                    "NOT_AN_OBJECT_CAUSES_JSON_EXCEPTION"
                  ]
                }
            """.trimIndent()

            val brokenResult = repo.importBackupJson(brokenMidImportJson)
            assertTrue(brokenResult.isFailure)
            val notesAfterRollback = repo.allNotesWithTags.first()
            assertEquals(1, notesAfterRollback.size)
            assertEquals("สมการกำลังสอง", notesAfterRollback.first().note.title)
        } finally {
            db.close()
        }
    }

    @Test
    fun `soft delete moves note to trash, restore brings it back, and 30 day purge removes expired notes`() = runBlocking {
        val db = buildInMemoryDb()
        try {
            val repo = NotesRepository(appContext(), db)
            val tagId = repo.createOrGetTag("เรขาคณิต", 3)
            val noteId = repo.saveNote(
                existingId = 0L,
                title = "ทฤษฎีบทพีทาโกรัส",
                subjectId = SubjectCategory.MATH.name,
                content = "[ ] ทบทวน",
                formulas = listOf(FormulaBlock(title = "พีทาโกรัส", expression = "c² = a² + b²")),
                imagePaths = emptyList(),
                tagIds = listOf(tagId),
                isPinned = true,
                needsReview = false,
                paperStyle = 2
            )

            repo.softDeleteNote(noteId)
            assertTrue(repo.allNotesWithTags.first().isEmpty())
            assertEquals(1, repo.trashedNotesWithTags.first().size)

            repo.restoreNoteFromTrash(noteId)
            assertEquals(1, repo.allNotesWithTags.first().size)
            assertTrue(repo.trashedNotesWithTags.first().isEmpty())

            // Toggle checklist line in DB
            repo.toggleChecklistLine(noteId, 0)
            assertEquals("[x] ทบทวน", repo.getNoteSnapshot(noteId)?.note?.content)

            // Save an expired trashed note (31 days old) and verify purge
            val now = System.currentTimeMillis()
            repo.saveNote(
                existingId = 0L,
                title = "โน้ตหมดอายุ",
                subjectId = SubjectCategory.GENERAL.name,
                content = "เก่าเกิน 30 วัน",
                formulas = emptyList(),
                imagePaths = emptyList(),
                tagIds = emptyList(),
                isPinned = false,
                needsReview = false,
                paperStyle = 0,
                deletedAt = now - TimeUnit.DAYS.toMillis(31)
            )
            assertEquals(1, repo.trashedNotesWithTags.first().size)
            val purged = repo.purgeExpiredTrash(retentionDays = 30L, nowMillis = now)
            assertEquals(1, purged)
            assertTrue(repo.trashedNotesWithTags.first().isEmpty())
        } finally {
            db.close()
        }
    }

    @Test
    fun `deleting custom subject reassigns its notes to GENERAL without data loss`() = runBlocking {
        val db = buildInMemoryDb()
        try {
            val repo = NotesRepository(appContext(), db)
            val custom = repo.createCustomSubject("แคลคูลัส 2", 0xFF7C3AED)
            val noteId = repo.saveNote(
                existingId = 0L,
                title = "อินทิกรัลหลายชั้น",
                subjectId = custom.id,
                content = "เนื้อหา",
                formulas = emptyList(),
                imagePaths = emptyList(),
                tagIds = emptyList(),
                isPinned = false,
                needsReview = false,
                paperStyle = 0
            )
            repo.deleteCustomSubject(custom.id)
            val updatedNote = repo.getNoteSnapshot(noteId)?.note
            assertNotNull(updatedNote)
            assertEquals(SubjectCategory.GENERAL.name, updatedNote!!.subject)
        } finally {
            db.close()
        }
    }

    @Test
    fun `migration 2 to 3 preserves existing notes, exams, sessions and seeds default subjects`() = runBlocking {
        val dbName = "migration_2_to_3_test.db"
        appContext().deleteDatabase(dbName)

        // Create a real v2 SQLite schema with pre-existing user data
        val helperConfig = SupportSQLiteOpenHelper.Configuration.builder(appContext())
            .name(dbName)
            .callback(object : SupportSQLiteOpenHelper.Callback(2) {
                override fun onCreate(db: SupportSQLiteDatabase) {
                    db.execSQL(
                        "CREATE TABLE IF NOT EXISTS `notes` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT NOT NULL, `subject` TEXT NOT NULL, `content` TEXT NOT NULL, `formulas` TEXT NOT NULL, `isPinned` INTEGER NOT NULL, `needsReview` INTEGER NOT NULL, `paperStyle` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL)"
                    )
                    db.execSQL(
                        "CREATE TABLE IF NOT EXISTS `tags` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `colorIndex` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL)"
                    )
                    db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_tags_name` ON `tags` (`name`)")
                    db.execSQL(
                        "CREATE TABLE IF NOT EXISTS `note_tag_cross_ref` (`noteId` INTEGER NOT NULL, `tagId` INTEGER NOT NULL, PRIMARY KEY(`noteId`, `tagId`), FOREIGN KEY(`noteId`) REFERENCES `notes`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE , FOREIGN KEY(`tagId`) REFERENCES `tags`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )"
                    )
                    db.execSQL("CREATE INDEX IF NOT EXISTS `index_note_tag_cross_ref_noteId` ON `note_tag_cross_ref` (`noteId`)")
                    db.execSQL("CREATE INDEX IF NOT EXISTS `index_note_tag_cross_ref_tagId` ON `note_tag_cross_ref` (`tagId`)")
                    db.execSQL(
                        "CREATE TABLE IF NOT EXISTS `exam_countdowns` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT NOT NULL, `subject` TEXT NOT NULL, `examDateMillis` INTEGER NOT NULL, `note` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)"
                    )
                    db.execSQL(
                        "CREATE TABLE IF NOT EXISTS `study_sessions` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `subject` TEXT NOT NULL, `durationMinutes` INTEGER NOT NULL, `completedAt` INTEGER NOT NULL)"
                    )

                    db.execSQL(
                        "INSERT INTO notes (id, title, subject, content, formulas, isPinned, needsReview, paperStyle, createdAt, updatedAt) " +
                            "VALUES (10, 'โน้ตเดิม v2', 'MATH', 'ยังอยู่ครบ', '[]', 1, 0, 0, 1700000000000, 1700000001000)"
                    )
                    db.execSQL(
                        "INSERT INTO exam_countdowns (id, title, subject, examDateMillis, note, createdAt) " +
                            "VALUES (5, 'สอบ v2', 'PHYSICS', 1760000000000, 'อ่านบท 1', 1700000000000)"
                    )
                    db.execSQL(
                        "INSERT INTO study_sessions (id, subject, durationMinutes, completedAt) " +
                            "VALUES (7, 'CHEMISTRY', 30, 1700000000000)"
                    )
                }

                override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
            })
            .build()

        FrameworkSQLiteOpenHelperFactory().create(helperConfig).writableDatabase.close()

        val migratedDb = Room.databaseBuilder(appContext(), AppDatabase::class.java, dbName)
            .addMigrations(AppDatabase.MIGRATION_1_2, AppDatabase.MIGRATION_2_3)
            .allowMainThreadQueries()
            .build()

        try {
            val repo = NotesRepository(appContext(), migratedDb)
            val notes = repo.allNotesWithTags.first()
            assertEquals(1, notes.size)
            assertEquals("โน้ตเดิม v2", notes.first().note.title)
            assertTrue(notes.first().note.imagePaths.isEmpty())
            assertEquals(null, notes.first().note.deletedAt)
            assertFalse(notes.first().note.isPinned.not())

            assertEquals(1, repo.allExams.first().size)
            assertEquals(1, repo.allStudySessions.first().size)
            assertTrue(repo.allSubjects.first().size >= SubjectCategory.entries.size)
        } finally {
            migratedDb.close()
            appContext().deleteDatabase(dbName)
        }
    }

    @Test
    fun `timestamp focus timer computes remaining seconds accurately`() {
        val start = 1_000_000L
        val end = start + 25 * 60 * 1000L
        assertEquals(1500, NotesViewModel.computeRemainingSeconds(end, start))
        assertEquals(600, NotesViewModel.computeRemainingSeconds(end, start + 15 * 60 * 1000L))
        assertEquals(1, NotesViewModel.computeRemainingSeconds(end, end - 500L))
        assertEquals(0, NotesViewModel.computeRemainingSeconds(end, end))
        assertEquals(0, NotesViewModel.computeRemainingSeconds(end, end + 5000L))
    }
}
