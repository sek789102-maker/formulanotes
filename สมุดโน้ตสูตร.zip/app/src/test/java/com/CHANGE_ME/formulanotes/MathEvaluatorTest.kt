package com.CHANGE_ME.formulanotes

import com.CHANGE_ME.formulanotes.domain.math.EvalResult
import com.CHANGE_ME.formulanotes.domain.math.MathErrorCode
import com.CHANGE_ME.formulanotes.domain.math.MathEvaluator
import com.CHANGE_ME.formulanotes.domain.math.UnitCategory
import com.CHANGE_ME.formulanotes.domain.math.UnitConverterEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MathEvaluatorTest {

    @Test
    fun `evaluates unicode operators, powers, and trig in degrees`() {
        val res1 = MathEvaluator.evaluate("2 × (3 + 4)² − √(16)") as EvalResult.Success
        assertEquals("94", res1.formatted)

        val res2 = MathEvaluator.evaluate("sin(30) + cos(60)", useDegrees = true) as EvalResult.Success
        assertEquals("1", res2.formatted)
    }

    @Test
    fun `inspects formula variables including subscripts and evaluates with values`() {
        val parsed = MathEvaluator.inspectFormula("E = 0.5 × m × v²")
        assertEquals("E", parsed.targetLabel)
        assertEquals(listOf("m", "v"), parsed.variables)

        val res = MathEvaluator.evaluate("E = 0.5 × m × v²", mapOf("m" to 4.0, "v" to 5.0))
        assertTrue(res is EvalResult.Success)
        assertEquals("50", (res as EvalResult.Success).formatted)
    }

    @Test
    fun `handles division by zero gracefully`() {
        val res = MathEvaluator.evaluate("10 ÷ 0")
        assertTrue(res is EvalResult.Error)
        assertEquals(MathErrorCode.DIVISION_BY_ZERO, (res as EvalResult.Error).code)
    }

    @Test
    fun `converts student science units accurately`() {
        val tempUnits = UnitConverterEngine.unitsByCategory[UnitCategory.TEMPERATURE]!!
        val celsius = tempUnits.first { it.id == "C" }
        val fahrenheit = tempUnits.first { it.id == "F" }
        val kelvin = tempUnits.first { it.id == "K" }

        assertEquals(212.0, UnitConverterEngine.convert(UnitCategory.TEMPERATURE, 100.0, celsius, fahrenheit), 1e-6)
        assertEquals(273.15, UnitConverterEngine.convert(UnitCategory.TEMPERATURE, 0.0, celsius, kelvin), 1e-6)
    }
}
